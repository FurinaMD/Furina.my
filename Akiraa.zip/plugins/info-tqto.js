let handler = async (m, { text }) => {
let capt = `*Big Thanks To*


• Bang Syai
• Ritz
• Fakrul
• Lexic Team
• Akira Team
• Betabotz`
conn.sendMessage(m.chat, {
  image: { url: `https://telegra.ph/file/18e7bc8b149917d645f18.jpg` },
  caption: capt,
  contextInfo: {
    isForwarded: true,
    forwardingScore: 9999,
    forwardedNewsletterMessageInfo: {
      newsletterJid: '120363330588681517@newsletter',
      serverMessageId: '482EF217AF2B029F25D5689CA39A1334',
      newsletterName: 'Silvia MD By Fakrul',
     },
   },
}, {quoted:m});
}
handler.help = handler.command = ['tqto']
handler.tags = ['info']

module.exports = handler