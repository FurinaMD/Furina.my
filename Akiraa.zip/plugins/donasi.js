const fs = require('fs');
const { generateWAMessageFromContent, proto, prepareWAMessageMedia } = require("akiraa-baileys");

const handler = async (m, { conn }) => {
  let ppUrl = await conn.profilePictureUrl(m.sender, 'image').catch((_) => "https://telegra.ph/file/54e758199b3faef966e24.jpg");
  let payText = `Ini adalah qris atau nomor dana yang mau donasi terimakasih`;

  // Persiapan media gambar
  const media = await prepareWAMessageMedia({ image: { url: 'https://telegra.ph/file/54e758199b3faef966e24.jpg' } }, { upload: conn.waUploadToServer });

  let msg = generateWAMessageFromContent(m.chat, proto.Message.fromObject({
    viewOnceMessage: {
      message: {
        "messageContextInfo": {
          "deviceListMetadata": {},
          "deviceListMetadataVersion": 2
        },
        interactiveMessage: proto.Message.InteractiveMessage.create({
          contextInfo: {
            mentionedJid: [m.sender],
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
              newsletterJid: '120363330588681517@newsletter',
              newsletterName: 'Powered By Silvia',
              serverMessageId: -1
            },
            businessMessageForwardInfo: { businessOwnerJid: conn.decodeJid(conn.user.id) },
            externalAdReply: {
              title: 'Silvia - MD',
              thumbnailUrl: 'https://telegra.ph/file/54e758199b3faef966e24.jpg',
              sourceUrl: 'https://whatsapp.com/channel/0029VahdkpZ6GcGO29mUq51f',
              mediaType: 1,
              renderLargerThumbnail: true
            }
          },
          body: proto.Message.InteractiveMessage.Body.create({
            text: payText
          }),
          footer: proto.Message.InteractiveMessage.Footer.create({
            text: 'Donasi dengan nomor klik di bawah'
          }),
          header: proto.Message.InteractiveMessage.Header.create({
            title: `*Hello, @${m.sender.replace(/@.+/g, '')}!*`,
            subtitle: "Fakrul",
            hasMediaAttachment: true,
            ...media
          }),
          nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
            buttons: [
              {
                name: "cta_copy",
                buttonParamsJson: `{\"display_text\":\"nomor dana\",\"id\":\"123456789\",\"copy_code\":\"083844082339\"}`
              }
            ]
          })
        })
      }
    }
  }), { userJid: m.chat, quoted: m });

  await conn.relayMessage(m.chat, msg.message, {
    messageId: msg.key.id
  });
}

handler.command = /^(donasi|donate)$/i;
handler.tags = ['info'];
handler.help = ['donasi', 'donate'];

module.exports = handler;