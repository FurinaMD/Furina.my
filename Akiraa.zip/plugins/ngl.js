
var handler = async (m, { text }) => {
if (!text.split("|")[0] && !text.split("|")[1]) return m.reply("Masukan username dan pesannya!\nContoh: .ngl mannr|haloo")
try {
let x = text.split("|")
var { data } = await require("axios")({
  "method": "GET",
  "url": "https://manaxu-seven.vercel.app/api/tools/ngl?username=" + x[0] + "&message=" + x[1]
})
m.reply("Sukses mengirim ngl ke " + x[0])
} catch (e) {
return m.reply("fitur error")
}
}
handler.command = handler.help = ["ngl"]
handler.tags = ["tools"]

module.exports = handler