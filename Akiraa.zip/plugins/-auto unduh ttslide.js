const axios = require('axios');
const fetch = require('node-fetch');
const cheerio = require("cheerio")

exports.before = async function(m) {
    const tiktokRegex = /https:\/\/(?:www\.tiktok\.com|vt\.tiktok\.com)\/(?:@[\w.-]+\/video\/\d+|v\/\d+|.*\/[\w.-]+\/video\/\d+|[\w.-]+)\b/g;
    const matches = m.text.trim().match(tiktokRegex);
    if (!matches) return false;

    await conn.sendMessage(m.chat, { react: { text: '⏱️', key: m.key } }); 

    try {
        const media = await getTikTokMedia(matches[0]);

        if (!media) {
            await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); 
            return conn.reply(m.chat, 'Gagal mengunduh media, coba lagi nanti. \nerror: ', m);
        }

        await conn.sendMessage(m.chat, { react: { text: '✅', key: m.key } });

        let caption = `*Downloader TikTok*`;

        if (Array.isArray(media)) {
            // Mengirim slide gambar satu per satu
            for (let i = 0; i < media.length; i++) {
                if (i === 0) {
                    await conn.sendMessage(m.chat, { image: { url: media[i] }, caption: `Mengirim 1 dari ${media.length} slide gambar.\n_(Sisanya akan dikirim via chat pribadi.)_` }, { quoted: m });
                } else {
                    await conn.sendMessage(m.sender, { image: { url: media[i] } }, { quoted: m });
                }
            }
        } else {
            await conn.sendFile(m.chat, media.downloadLink, "", caption, m);
        }

    } catch (e) {
        await conn.sendMessage(m.chat, { react: { text: '❌', key: m.key } }); 
        console.error('Error saat sedang memproses:', e);
        return conn.reply(m.chat, 'Sedang Error', m);
    }
}

exports.disabled = false;

async function getTikTokMedia(url) {
    if (url.includes('vt.tiktok.com')) {
        // Menangani URL yang disingkat dari vt.tiktok.com dengan mengikuti redirect biar ga error
        try {
            const response = await fetch(url, { redirect: 'manual' });
            if (response.status === 301 || response.status === 302) {
                url = response.headers.get('location'); // Mengambil URL dari header lokasi
            } else {
                throw new Error('Tidak dapat mengikuti redirect URL.');
            }
        } catch (error) {
            throw new Error('Tidak dapat mengurai URL dari vt.tiktok.com');
        }
    }

    if (url.includes('video')) {
        // Jika video
        const encodedParams = new URLSearchParams({ url: url }).toString();
        const response = await axios.post('https://tikwm.com/api/', encodedParams, {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Cookie': 'current_language=en',
                'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Mobile Safari/537.36'
            }
        });
        const videos = response.data.data;
        return { 
            downloadLink: videos.play 
        };
    } else {

        let api = `https://dlpanda.com/id?url=${url}&token=G7eRpMaa`
		let response = await axios.get(api)
		const html = response.data
		const $ = cheerio.load(html)
		let nzx = []
		let img = []
		
		$('div.col-md-12 > img').each((index, element) => {
			img.push($(element).attr('src'))
		})
		
		nzx.push({ img })
		let res = img.map((e, i) => {
			return e
		})
		return res
    }
}