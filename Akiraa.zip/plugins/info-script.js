const handler = async (m, { conn }) => {
    conn.sendButton(m.chat,[["CHAT OWNER",".owner"]], m, {
footer : `S E L L - S C R I P T

* Name : Silvia MD
* Type : plugins ( Cjs )
* Features : 800+
* Example bot : [ https://chat.whatsapp.com/KRq8ByFIMikJasN8e1IUkX ]
* Price :* 50.000

* support qr/pairing 
* Support button
* Size dibawah 5Mb
* 80% Scrape 

• Preview Features :
* Tiltok downloader 
* Ig Downloader 
* ytmp4/ytmp3
* Function Button Url
* Cpanel menu 
* Tools-ceknik
* Tools-lacakip
* backupsc
* Remove bg
* Jadibot 
* Yt downloader 
* Yt search 
* Yt channel 
* Tiktok search 
* Nekopoi search/detail/latest
* Menfess/Confess
* Block/Unblock Cmd
* Txt2img 
* Bingimg
* GptImg
* Luminai
* Jadianime
* Ai/Gpt

• Benefit :
* Free Update always Time !
* Free Apikey Premium 

• Payment :
* DANA
* Qris

• Contact me :
`,
url: "https://telegra.ph/file/18e7bc8b149917d645f18.jpg" 
})
};

handler.help = ["script", "sc"].map((a) => a + " *[get script]*");
handler.tags = ["info"];
handler.command = ["script", "sc"];
handler.owner = false;
module.exports = handler;