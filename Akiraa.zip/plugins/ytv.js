const yts = require("yt-search");
const ytdl = require("node-yt-dl");

module.exports = {
  help: ["ytmp4", "ytv"].map((a) => a + " *[YouTube url]*"),
  tags: ["downloader"],
  command: ["ytmp4", "ytv"],
  code: async (
    m,
    {
      conn,
      usedPrefix,
      command,
      text,
      isOwner,
      isAdmin,
      isBotAdmin,
      isPrems,
      chatUpdate,
    },
  ) => {
    if (!text) throw `*• Example :* ${usedPrefix + command} *[url]*`;
    m.reply(wait);
    let search;
    if (Func.isUrl(text)) {
      search = await yts(videoId(text));
    } else {
      search = await yts(text);
    }
    let hasil = search.videos[0];
    let download = await ytdl.mp4(hasil.url);
    let cap = `${download.title}

* *Metadata Info :*
${Object.entries(download.metadata)
  .map(([a, b]) => `* *${a}* : ${b}`)
  .join("\n")}

* *Author Info :*
${Object.entries(download.author)
  .map(([a, b]) => `* *${a}* : ${b}`)
  .join("\n")}`;
    conn.sendMessage(
      m.chat,
      {
        video: {
          url: download.media,
        },
        caption: cap,
      },
      {
        quoted: m,
      },
    );
  },
};

function videoId(url) {
  const regex =
    /(?:https?:\/\/)?(?:www\.)?(?:youtu\.be\/|youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/shorts\/|youtube\.com\/embed\/)([\w\-]+)/;
  const match = url.match(regex);

  if (match && match[1]) {
    return match[1];
  } else {
    return "VideoId tidak ditemukan";
  }
}
