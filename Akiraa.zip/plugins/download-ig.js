let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `*• Example :* ${usedPrefix + command} *[Instagram url]*`;
  if (!Func.isUrl(text))
    throw `*• Example :* ${usedPrefix + command} *[Instagram url]*`;
  m.reply(wait);
  try {
    let media = await Func.fetchJson(
      "https://widipe.com/download/igdl?url=" + text,
    );
    if (media.length === 0) throw "*[ NO MEDIA FOUND ]*";
    for (let i of media.result) {
      m.reply("*[ INSTAGRAM DOWNLOADER ]*", i.url);
    }
  } catch (e) {
    throw eror;
  }
};
handler.help = ["ig", "igdl"].map((a) => a + " *[Instagram url]*");
handler.tags = ["downloader"];
handler.command = ["ig", "igdl"];

module.exports = handler;
