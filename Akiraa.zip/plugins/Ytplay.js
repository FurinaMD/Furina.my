/*const ytdl = require("ytdl-core");
const yts = require("yt-search");
const fs = require("fs");
const { pipeline } = require("stream");
const { promisify } = require("util");
const streamPipeline = promisify(pipeline);
const os = require("os");
const {
  generateWAMessageFromContent,
  proto,
  prepareWAMessageMedia,
} = require("@whiskeysockets/baileys");

// Function to format numbers with commas
function formatNumber(number) {
  return number.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

const handler = async (m, { conn, command, text, usedPrefix }) => {
  conn.play = conn.play || {};
  if (!text) throw `*• Example :* ${usedPrefix + command} Wide Awake`;
  
  conn.chatRead(m.chat);
  conn.sendMessage(m.chat, {
    react: {
      text: '⚡',
      key: m.key,
    }
  });

  let url;

  try {
    const search = await yts(text);
    if (!search) throw "Not Found, Try Another Title";
    const vid = search.videos[0];
    const { title, thumbnail, views, ago, url: videoUrl, seconds } = vid;
    if (seconds > 3600)
      return m.reply(
        "*[ DURATION TOO LONG ]*\nI cannot download media that exceeds *1 hour* duration.",
      );

    url = videoUrl;
    const caption = `*◦ Title:* ${title}\n*◦ Views:* ${formatNumber(views)}\n*◦ Uploaded:* ${ago}\n*◦ Duration:* ${seconds} seconds\n*◦ Link:* ${url}\n_*Sending Audio...*_`;
    let msg = generateWAMessageFromContent(m.chat, {
      viewOnceMessage: {
        message: {
          "messageContextInfo": {
            "deviceListMetadata": {},
            "deviceListMetadataVersion": 2
          },
          interactiveMessage: proto.Message.InteractiveMessage.create({
            contextInfo: {
              stanzaId: m.key.id,
              remoteJid: m.isGroup ? m.chat : m.key.remoteJid,
              participant: m.key.participant || m.sender,
              fromMe: m.key.fromMe,
              quotedMessage: m.message,
              mentionedJid: [m.sender],
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: '120363330588681517@newsletter',
                newsletterName: `${title}`,
                serverMessageId: 607,
              },
              externalAdReply: {
                title: title,
                body: `${seconds} seconds`,
                thumbnailUrl: thumbnail,
                sourceUrl: thumbnail,
                mediaType: 1,
                renderLargerThumbnail: true
              }
            },
            body: proto.Message.InteractiveMessage.Body.create({
              text: "*[ YOUTUBE PLAY ]*",
            }),
            footer: proto.Message.InteractiveMessage.Footer.create({
              text: caption,
            }),
            header: proto.Message.InteractiveMessage.Header.create({
              hasMediaAttachment: true,
              ...(await prepareWAMessageMedia(
                { image: { url: thumbnail } },
                { upload: conn.waUploadToServer },
              )),
            }),
            nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
              buttons: [
                {
                  name: "quick_reply",
                  buttonParamsJson: `{\"display_text\":\"Download Video\",\"id\":\".ytv ${url}\"}`,
                },
                {
                  name: "cta_url",
                  buttonParamsJson: `{"display_text":"View on YouTube","url":"${url}","merchant_url":"${url}"}`
                },
              ],
            }),
          }),
        },
      },
    }, {});

    const t = await conn.relayMessage(msg.key.remoteJid, msg.message, {
      messageId: msg.key.id
    });

    const audioStream = ytdl(videoUrl, {
      filter: "audioonly",
      quality: "highestaudio",
    });

    const tmpDir = os.tmpdir();
    const writableStream = fs.createWriteStream(`${tmpDir}/${title}.mp3`);

    await streamPipeline(audioStream, writableStream);

    let doc = {
      audio: { url: `${tmpDir}/${title}.mp3` },
      mimetype: "audio/mp4",
      fileName: title,
      contextInfo: {
        externalAdReply: {
          showAdAttribution: true,
          mediaType: 2,
          mediaUrl: videoUrl,
          title: title,
          sourceUrl: videoUrl,
          thumbnail: (await conn.getFile(thumbnail)).data,
        },
      },
    };

    await conn.sendMessage(m.chat, doc, { quoted: m });
    conn.sendMessage(m.chat, {
      react: {
        text: '💚',
        key: m.key,
      }
    });

    fs.unlink(`${tmpDir}/${title}.mp3`, (err) => {
      if (err) console.error(`Failed to delete audio file: ${err}`);
      else console.log(`Deleted audio file: ${tmpDir}/${title}.mp3`);
    });
  } catch (error) {
    throw error;
  }
};

handler.help = ["ytplay *[query]*"];
handler.tags = ["downloader"];
handler.command = /^(ytplay)$/i;
handler.restrict = false;

module.exports = handler;*/




const axios = require("axios");
const yts = require("yt-search");
const fs = require("fs");
const { pipeline } = require("stream");
const { promisify } = require("util");
const os = require("os");


const streamPipeline = promisify(pipeline);

let handler = async (m, { conn, command, text, usedPrefix }) => {
  if (!text) throw `Gunakan contoh ${usedPrefix}${command} Ho Hey`;

  await conn.reply(m.chat, "_「P R O C E S S 」_\n Sedang mencari dan mengunduh audio...", m);

  let search = await yts(text);
  let vid = search.videos[0];
  if (!vid) throw 'Video tidak ditemukan, coba judul lain';
  let { title, thumbnail, timestamp, views, ago, url } = vid;
  let wm = 'Henry-AI Search';
  let wm2 = 'Played by Henry-AI';

  let captvid = `╭──── 〔 Y O U T U B E 〕 ─⬣
  ⬡ Title: ${title}
  ⬡ Duration: ${timestamp}
  ⬡ Views: ${views}
  ⬡ Uploaded: ${ago}
  ⬡ Link: ${url}
╰────────⬣`;

  let infoMessage = {
    image: { url: thumbnail },
    caption: captvid,
    viewOnce: false,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 2,
        mediaUrl: url,
        title: "© Yousoo",
        body: wm,
        sourceUrl: url,
        thumbnailUrl: thumbnail
      }
    }
  };

  await conn.sendMessage(m.chat, infoMessage, { quoted: m });

  const response = await axios.get(`https://api.shannmoderz.xyz/downloader/yt-audio?url=${encodeURIComponent(url)}`);
  const mp3Url = response.data.result.download_url;

  const audioResponse = await axios.get(mp3Url, { responseType: 'stream' });

  const tmpDir = os.tmpdir();
  const audioFilePath = `${tmpDir}/${title}.mp3`;
  const writableStream = fs.createWriteStream(audioFilePath);

  await streamPipeline(audioResponse.data, writableStream);

  let audioMessage = {
    audio: {
      url: audioFilePath
    },
    mimetype: 'audio/mp4',
    fileName: `${title}`,
    contextInfo: {
      externalAdReply: {
        showAdAttribution: true,
        mediaType: 2,
        mediaUrl: url,
        title: title,
        body: wm2,
        sourceUrl: url,
        thumbnailUrl: thumbnail
      }
    }
  };

  await conn.sendMessage(m.chat, audioMessage, { quoted: m });

  fs.unlink(audioFilePath, (err) => {
    if (err) {
      console.error(`Gagal menghapus file audio: ${err}`);
    } else {
      console.log(`File audio dihapus: ${audioFilePath}`);
    }
  });
};

handler.help = ['youtubeplay'].map(v => v + ' name/url');
handler.tags = ['downloader'];
handler.command = /^(ytplay|youtubeplay)$/i;
handler.register = true
handler.premium = false;
handler.limit = true;
module.exports = handler;
