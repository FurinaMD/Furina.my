let handler = async (m, { conn, text, participants, usedPrefix, command }) => {
  if (!text) throw `• Example : ${usedPrefix + command} [input text]`;
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";
  let groups = Object.entries(conn.chats)
    .filter(
      ([jid, chat]) =>
        jid.endsWith("@g.us") &&
        chat.isChats &&
        !chat.metadata?.read_only &&
        !chat.metadata?.announce,
    )
    .map((v) => v[0]);
  conn.reply(m.chat, `Sending Broadcast to Group : [ ${groups.length} ]`, m);
  for (let id of groups) {
    let participantIds = participants.map((a) => a.id);
    if (mime) {
      let buffer = await q.download();
      conn.sendUrl(
        id,
        [
          ["ORDER NOW", "https://wa.me/6383187610223"],
          ["MARKETPLACE", "https://chat.whatsapp.com/B8pXE5442MWKJmYibDtr0F"],
          
        ],
        fkontak,
        {
          body: text,
          url: await Uploader.catbox(buffer),
        },
      );
      await conn.delay(1000);
    } else {
      conn.sendUrl(
        id,
        [
          ["ORDER NOW", "https://wa.me/6383187610223"],
          ["MARKETPLACE", "https://chat.whatsapp.com/B8pXE5442MWKJmYibDtr0F"],
          
        ],
        fkontak,
        {
          body: text,
        },
      );
      await conn.delay(1000);
    }
  }
};

handler.help = ["jpm"].map((v) => v + " *[input text]*");
handler.tags = ["owner"];
handler.command = ["jpm"];
handler.owner = true;
module.exports = handler;

const more = String.fromCharCode(8206);
const readMore = more.repeat(4001);

const randomID = (length) =>
  require("crypto")
    .randomBytes(Math.ceil(length * 0.5))
    .toString("hex")
    .slice(0, length);
