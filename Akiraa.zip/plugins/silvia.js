const axios = require('axios');

let handler = async (m, { conn, text }) => {
    conn.arona2 = conn.arona2 ? conn.arona2 : {};

    if (!text) throw `*• Example:* .silvia *[on/off]*`;

    if (text === "on") {
        conn.arona2[m.sender] = {
            pesan: []
        };
        m.reply("Halo ayang! silvia yang hebat siap membantu!");
    } else if (text === "off") {
        delete conn.arona2[m.sender];
        m.reply("panggil aku lagi jika kamu butuh bantuan ya!");
    }
};

handler.before = async (m, { conn }) => {
    conn.arona2 = conn.arona2 ? conn.arona2 : {};
    if (m.isBaileys && m.fromMe) return;
    if (!m.text) return;
    if (!conn.arona2[m.sender]) return;

    if (
        m.text.startsWith(".") ||
        m.text.startsWith("#") ||
        m.text.startsWith("!") ||
        m.text.startsWith("/") ||
        m.text.startsWith("\\/")
    ) return;

    if (conn.arona2[m.sender] && m.text) {
        let name = conn.getName(m.sender);
        await conn.sendMessage(m.chat, { react: { text: `⏱️`, key: m.key }});
        const messages = [
            ...conn.arona2[m.sender].pesan,
            `Ubah gaya bicaramu agar lebih imut dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Silvia dan kamu adalah bot dari Fakrul Jika ada yang memanggilmu Sayang Selain Fakrul Kamu akan marah. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara${name}, kamu memiliki sifat seperti cewek imut `,
            m.text
        ];
        try {
            // const response = await axios.get(`https://api.betabotz.eu.org/api/search/openai-logic`, {
            //     params: {
            //         text: m.text,
            //         logic: JSON.stringify(messages),
            //         apikey: `${lann}`
            //     }
            // }); 
            let res = await fetch(`https://api.betabotz.eu.org/api/search/openai-logic?text=${m.text}&logic=${messages}&apikey=${lann}`)
            let json = await res.json()
            let data = json.message
            conn.sendMessage(m.chat, {
                text: "⬣───「 *Silvia - MD* 」───⬣" + "\n\n" + data,
                contextInfo: {
                  externalAdReply: {  
                    title: "Silvia - MD",
                    body: '',
                    thumbnailUrl:`https://telegra.ph/file/18e7bc8b149917d645f18.jpg`,
                    sourceUrl: null,
                    mediaType: 1,
                    renderLargerThumbnail: true
                  }
                }
              }, { quoted: m });
            } catch (error) {
                console.error(error);
                throw 'Maaf terjadi masalah!';
              }
    }
};

handler.command = ['silvia'];
handler.tags = ["ai"];
handler.help = ['silvia'].map(a => a + " *[on/off]*");
handle.group = true
handle.admin = true
module.exports = handler;