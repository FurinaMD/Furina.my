const moment = require("moment-timezone");
const PhoneNumber = require("awesome-phonenumber");
const fs = require("fs");
const fetch = require("node-fetch");
const os = require("os");
const freeMemory = os.freemem();
const totalMemory = os.totalmem();
const usedMemory = totalMemory - freeMemory;
const {
  generateWAMessageFromContent,
  proto,
  prepareWAMessageMedia,
} = require("akiraa-baileys");


let menulist = async (m, { conn, usedPrefix, command, args }) => {
  const perintah = args[0] || "tags";
  const tagCount = {};
  const tagHelpMapping = {};
const user = global.db.data.users[m.sender] 


  Object.keys(global.plugins)
    .filter((plugin) => !plugin.disabled)
    .forEach((plugin) => {
      const tagsArray = Array.isArray(global.plugins[plugin].tags)
        ? global.plugins[plugin].tags
        : [];

      if (tagsArray.length > 0) {
        const helpArray = Array.isArray(global.plugins[plugin].help)
          ? global.plugins[plugin].help
          : [global.plugins[plugin].help];

        tagsArray.forEach((tag) => {
          if (tag) {
            if (tagCount[tag]) {
              tagCount[tag]++;
              tagHelpMapping[tag].push(...helpArray);
            } else {
              tagCount[tag] = 1;
              tagHelpMapping[tag] = [...helpArray];
            }
          }
        });
      }
    });

  let help = Object.values(global.plugins)
    .filter((plugin) => !plugin.disabled)
    .map((plugin) => {
      return {
        help: Array.isArray(plugin.tags) ? plugin.help : [plugin.help],
        tags: Array.isArray(plugin.tags) ? plugin.tags : [plugin.tags],
        prefix: "customPrefix" in plugin,
        limit: plugin.limit,
        premium: plugin.premium,
        enabled: !plugin.disabled,
      };
    });

  if (perintah === "tags") {
    const daftarTag = Object.keys(tagCount)
      .sort()
      .join(`\n┃⬣ ${usedPrefix + command} `);
    const more = String.fromCharCode(8206);
    const readMore = more.repeat(4001);
    let _mpt;
    if (process.send) {
      process.send("uptime");
      _mpt =
        (await new Promise((resolve) => {
          process.once("message", resolve);
          setTimeout(resolve, 1000);
        })) * 1000;
    }
    let mpt = clockString(_mpt);
    let name = m.pushName || conn.getName(m.sender);
    let prn = thumb;
    let fitur = Object.values(plugins)
      .filter((v) => v.help && !v.disabled)
      .map((v) => v.help)
      .flat(1);
    let syaii = `${
      global.menu === "button"
        ? `🤡 Hi @${m.sender.split("@")[0]}
${namebot} Adalah sistem otomatis whatsApp yang dapat membantu anda dalam hal apapun di WhatsApp!!

saya di desain oleh Seorang Developer hebat yang mengembangkan bot whatsApp berbasis Javascript ini dengan menyajikan beberapa fitur seperti *AI*, *DOWNLOADER*, *GAME*, dan lainnya 

     *\`</> INFO BOT </>\`*
     
  ⫹⫺ *Name Bot :* ${namebot}
  ⫹⫺ *Total User :* ${Func.formatNumber(Object.keys(db.data.users).length)}
  ⫹⫺ *Total Chat:* ${Object.keys(conn.chats).length}
  ⫹⫺ *Uptime :* *[ ${Func.toTime(process.uptime() * 1000)} ]*
  ⫹⫺ *Total Memory :* ${Func.formatSize(totalMemory)}
  ⫹⫺ *Free Memory :* ${Func.formatSize(freeMemory)}
  ⫹⫺ *Used Memory :* ${Func.formatSize(usedMemory)}
  
     *\`</> INFO USER </>\`* 
    
  ⫹⫺ *Name User :* ${m.name}
  ⫹⫺ *Tag User :* @${m.sender.split("@")[0]}
  ⫹⫺ *Limit User  :* ${user.limit}
  ⫹⫺ *Premium :* ${user.premium ? "✓" : "x"}

*Silvia - MD V6*`
        : `${dash}
🤡 Hi @${m.sender.split("@")[0]}
${namebot} Adalah sistem otomatis whatsApp yang dapat membantu anda dalam hal apapun di WhatsApp!!

saya di desain oleh Seorang Developer hebat yang mengembangkan bot whatsApp berbasis Javascript ini dengan menyajikan beberapa fitur seperti *AI*, *DOWNLOADER*, *GAME*, dan lainnya 

     *\`</> INFO BOT </>\`*
     
  ⫹⫺ *Name Bot :* ${namebot}
  ⫹⫺ *Total User :* ${Func.formatNumber(Object.keys(db.data.users).length)}
  ⫹⫺ *Total Chat:* ${Object.keys(conn.chats).length}
  ⫹⫺ *Uptime :* ${Func.toDate(process.uptime() * 1000)} *[${Func.toTime(process.uptime() * 1000)}]*
  ⫹⫺ *Total Memory :* ${Func.formatSize(totalMemory)}
  ⫹⫺ *Free Memory :* ${Func.formatSize(freeMemory)}
  ⫹⫺ *Used Memory :* ${Func.formatSize(usedMemory)}
  
     *\`</> INFO USER </>\`* 
     
  ⫹⫺ *Name User :* ${m.name}
  ⫹⫺ *Tag User :* @${m.sender.split("@")[0]}
  ⫹⫺ *Limit User  :* ${user.limit}
  ⫹⫺ *Premium :* ${user.premium ? "✓" : "x"}
  
${readMore}
┌─⭓「 *L I S T - M E N U* 」
│⫹⫺ ${usedPrefix + command} all
│⫹⫺ ${usedPrefix + command} ${daftarTag}
└───────────────⭓`
    }

`;

    if (global.menu === "simple") {
      conn.reply(m.chat, syaii, fkontak);
    } else if (global.menu === "doc") {
      conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid.split("@")[0],
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: syaii,
          mimetype: "text/html",
          fileName: `Silvia MD By Fakrul`,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "gif") {
      conn.sendMessage(
        m.chat,
        {
          video: { url: gif },
          gifPlayback: true,
          gifAttribution: ~~(Math.random() * 2),
          caption: syaii,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            externalAdReply: {
              title: `Silvia MD By Fakrul`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(plugins)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: syaii,
                contextInfo: {
                  mentionedJid: conn.parseMention(syaii),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
    } else if (global.menu === "edit") {
      const arr = [
        "➳ *L*",
        "➳ *L O*",
        "➳ *L O A*",
        "➳ *L O A D*",
        "➳ *L O A D I*",
        "➳ *L O A D I N*",
        "➳ *L O A D I N G*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G . . .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G*",
        "➳ *W E L C O M E  T O  C H R I S T Y*",
        syaii,
      ];

      let { key } = await conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid,
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: `➳ *Please Waif...*`,
          mimetype: "text/html",
          fileName: `Silvia MD [ By Fakrul ]`,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
      for (let i = 0; i < arr.length; i++) {
        await conn.sendMessage(
          m.chat,
          {
            document: {
              url: "https://wa.me",
            },
            jpegThumbnail: await conn.resize(thumb, 300, 150),
            caption: arr[i],
            mimetype: "text/html",
            fileName: `Silvia MD [ By Fakrul ]`,
            edit: key,
            contextInfo: {
              mentionedJid: conn.parseMention(syaii),
              isForwarded: true,
              businessMessageForwardInfo: {
                businessOwnerJid: conn.user.jid,
              },
            },
          },
          { quoted: fkontak },
        );
      }
    } else if (global.menu === "button") {
      const list = Object.keys(tagCount);
      let array = [];
      for (let i of list) {
        array.push({
          header: `MENU ${i.toUpperCase()}`,
          title: `Menampilkan menu ${i}`,
          description: "",
          id: `${usedPrefix + command} ${i}`,
        });
      }

      let sections = [
        {
          title: "INFOMATION Silvia - MD",
          highlight_label: "view all features",
          rows: [
            {
              header: namebot,
              title: "MENU ALL",
              description: `🏷️ View All menu`,
              id: ".menu all",
            },
            {
              header: namebot,
              title: "SEWA BOT",
              description: `⭐ menyewa bot`,
              id: ".sewa",
            },
            {
              header: namebot,
              title: "INFO SCRIPT",
              description: `🤖 View script bot`,
              id: ".sc",
            },
            {
              header: "👤 CONTACT OWNER",
              title: "Owner Bot",
              description: "",
              id: ".owner",
            },
          ],
        },
        {
          title: "LIST MENU Silvia - MD",
          highlight_label: "view list Category menu",
          rows: [...array],
        },
      ];

      let listMessage = {
        title: "Click Here🏷️",
        sections,
      };

      let msg = generateWAMessageFromContent(
        m.chat,
        {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadata: {},
                deviceListMetadataVersion: 2,
              },
              interactiveMessage: proto.Message.InteractiveMessage.create(
                {
                  body: proto.Message.InteractiveMessage.Body.create({
                    text: syaii,
                  }),
                  footer: proto.Message.InteractiveMessage.Footer.create({
                    text: wm,
                  }),
                  header: proto.Message.InteractiveMessage.Header.create({
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia(
                      { image: { url: thumb }, fileLength: 1000000000000 },
                      { upload: conn.waUploadToServer },
                    )),
                  }),
                  nativeFlowMessage:
                    proto.Message.InteractiveMessage.NativeFlowMessage.create({
                      buttons: [
                        {
                          name: "single_select",
                          buttonParamsJson: JSON.stringify(listMessage),
                        },
                     {
              "name": "cta_url",
              "buttonParamsJson": JSON.stringify({
                display_text: "Information Bot👤",
                url: 'https://whatsapp.com/channel/0029VahdkpZ6GcGO29mUq51f',
                merchant_url: 'https://whatsapp.com/channel/0029VahdkpZ6GcGO29mUq51f'
                          }),
                        },
                      ],
                    }),
                  contextInfo: {
                    mentionedJid: [m.sender],
                  },
                },
                { quoted: m },
              ),
            },
          },
        },
        {},
      );

      await conn.relayMessage(msg.key.remoteJid, msg.message, {
        messageId: msg.key.id,
      });
    } else {
      conn.sendMessage(
        m.chat,
        {
          text: syaii,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            externalAdReply: {
              title: `Silvia - MD [ By Fakrul ]`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    }
  } else if (tagCount[perintah]) {
    const daftarHelp = tagHelpMapping[perintah]
      .map((helpItem, index) => {
        return `${helpItem}`;
      })
      .join("\n┃❖ " + " ");
    let syaii = `┏⭓「 *MENU ${perintah.toUpperCase()}* 」
┃❖ *${daftarHelp}*
┗━━━━━━━━━━━━⭓
`;
    if (global.menu === "simple") {
      conn.reply(m.chat, syaii, fkontak);
      } else if (global.menu === "doc") {
      conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid.split("@")[0],
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: syaii,
          mimetype: "text/html",
          fileName: `Silvia MD [ By Fakrul ]`,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "gif") {
      conn.sendMessage(
        m.chat,
        {
          video: { url: gif },
          gifPlayback: true,
          gifAttribution: ~~(Math.random() * 2),
          caption: syaii,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            externalAdReply: {
              title: `Silvia MD [ By Fakrul ]`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(plugins)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: syaii,
                contextInfo: {
                  mentionedJid: conn.parseMention(syaii),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
    } else if (global.menu === "edit") {
      const arr = [
        "➳ *L*",
        "➳ *L O*",
        "➳ *L O A*",
        "➳ *L O A D*",
        "➳ *L O A D I*",
        "➳ *L O A D I N*",
        "➳ *L O A D I N G*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G . . .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G*",
        "➳ *W E L C O M E  T O  C H R I S T Y*",
        syaii,
      ];

      let { key } = await conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid,
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: `➳ *Please Waif...*`,
          mimetype: "text/html",
          fileName: `Silvia MD [ By Fakrul ]`,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
      for (let i = 0; i < arr.length; i++) {
        await conn.sendMessage(
          m.chat,
          {
            document: {
              url: "https://wa.me",
            },
            jpegThumbnail: await conn.resize(thumb, 300, 150),
            caption: arr[i],
            mimetype: "text/html",
            fileName: `Silvia MD By Fakrul`,
            edit: key,
            contextInfo: {
              mentionedJid: conn.parseMention(syaii),
              isForwarded: true,
              businessMessageForwardInfo: {
                businessOwnerJid: conn.user.jid,
              },
            },
          },
          { quoted: fkontak },
        );
      }
   } else if (menu === "button") {
      conn.sendButton(m.chat,[["BACK TO MENU",".menu"],["SCRIPT",".sc"]], m, {
      body: syaii,
      url: thumb
      })
    } else {
      conn.sendMessage(
        m.chat,
        {
          text: syaii,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            externalAdReply: {
              title: `Silvia MD By Fakrul`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    }
  } else if (perintah === "all") {
    let name = m.pushName || conn.getName(m.sender);
    const more = String.fromCharCode(8206);
    const readMore = more.repeat(4001);
    const allTagsAndHelp = Object.keys(tagCount)
      .map((tag) => {
        const daftarHelp = tagHelpMapping[tag]
          .map((helpItem, index) => {
            return `${usedPrefix + helpItem}`;
          })
          .join("\n┃❖ " + " ");
        return `┏⭓「 *MENU ${tag.toUpperCase()}* 」
┃❖ *${daftarHelp}*
┗━━━━━━━━━━━━⭓
`;
          })
      .join("\n");
    let syaii = `🌟 Hi @${m.sender.split("@")[0]}
${namebot}, Diupgrade Dengan Fitur baru Dan akan terus update hingga versi terbaru, Jadi Tunggu apalagi beli sc Silvia AI Premium dengan ketik buyscript ✧ (⁠づ⁠｡⁠◕⁠‿⁠‿⁠◕⁠｡⁠)⁠づ⁠✧。

      *\`</> INFO BOT </>\`*
      
  ⫹⫺ *Name Bot :* ${namebot}
  ⫹⫺ *Total User :* ${Func.formatNumber(Object.keys(db.data.users).length)}
  ⫹⫺ *Total Chat:* ${Object.keys(conn.chats).length}
  ⫹⫺ *Uptime :* ${Func.toDate(process.uptime() * 1000)} *[${Func.toTime(process.uptime() * 1000)}]*
  ⫹⫺ *Total Memory :* ${Func.formatSize(totalMemory)}
  ⫹⫺ *Free Memory :* ${Func.formatSize(freeMemory)}
  ⫹⫺ *Used Memory :* ${Func.formatSize(usedMemory)}
  
      *\`</> INFO USER </>\`* 
      
  ⫹⫺ *Name User :* ${m.name}
  ⫹⫺ *Tag User :* @${m.sender.split("@")[0]}
  ⫹⫺ *Limit User  :* ${user.limit}
  ⫹⫺ *Premium :* ${user.premium ? "✓" : "x"}
  
${readMore}
${allTagsAndHelp}`;

    if (global.menu === "simple") {
      conn.reply(m.chat, syaii, fkontak);
        } else if (global.menu === "doc") {
      conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid.split("@")[0],
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: syaii,
          mimetype: "text/html",
          fileName: `Silvia MD By Fakrul`,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "gif") {
      conn.sendMessage(
        m.chat,
        {
          video: { url: gif },
          gifPlayback: true,
          gifAttribution: ~~(Math.random() * 2),
          caption: syaii,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            externalAdReply: {
              title: `Silvia MD By Fakrul`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    } else if (global.menu === "payment") {
      await conn.relayMessage(
        m.chat,
        {
          requestPaymentMessage: {
            currencyCodeIso4217: "USD",
            amount1000:
              Object.values(plugins)
                .filter((v) => v.help && !v.disabled)
                .map((v) => v.help)
                .flat(1).length * 1000,
            requestFrom: m.sender,
            noteMessage: {
              extendedTextMessage: {
                text: syaii,
                contextInfo: {
                  mentionedJid: conn.parseMention(syaii),
                  externalAdReply: {
                    showAdAttribution: true,
                  },
                },
              },
            },
          },
        },
        {},
      );
    } else if (global.menu === "edit") {
      const arr = [
        "➳ *L*",
        "➳ *L O*",
        "➳ *L O A*",
        "➳ *L O A D*",
        "➳ *L O A D I*",
        "➳ *L O A D I N*",
        "➳ *L O A D I N G*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G . . .*",
        "➳ *L O A D I N G . .*",
        "➳ *L O A D I N G .*",
        "➳ *L O A D I N G*",
        "➳ *W E L C O M E  T O  C H R I S T Y*",
        syaii,
      ];

      let { key } = await conn.sendMessage(
        m.chat,
        {
          document: {
            url: "https://wa.me/" + conn.user.jid,
          },
          jpegThumbnail: await conn.resize(thumb, 300, 150),
          caption: `➳ *Please Waif...*`,
          mimetype: "text/html",
          fileName: `Silvia MD By Fakrul`,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            isForwarded: true,
            businessMessageForwardInfo: {
              businessOwnerJid: conn.user.jid,
            },
          },
        },
        { quoted: fkontak },
      );
      for (let i = 0; i < arr.length; i++) {
        await conn.sendMessage(
          m.chat,
          {
            document: {
              url: "https://wa.me",
            },
            jpegThumbnail: await conn.resize(thumb, 300, 150),
            caption: arr[i],
            mimetype: "text/html",
            fileName: `Silvia MD By Fakrul`,
            edit: key,
            contextInfo: {
              mentionedJid: conn.parseMention(syaii),
              isForwarded: true,
              businessMessageForwardInfo: {
                businessOwnerJid: conn.user.jid,
              },
            },
          },
          { quoted: fkontak },
        );
      }
   } else if (menu === "button") {
      conn.sendButton(m.chat,[["BACK TO MENU",".menu"],["SCRIPT",".sc"]], m, {
      body: syaii,
      url: thumb
      })
    } else {
      conn.sendMessage(
        m.chat,
        {
          text: syaii,
          contextInfo: {
            mentionedJid: conn.parseMention(syaii),
            externalAdReply: {
              title: `Silvia MD By Fakrul`,
              body: wm,
              thumbnailUrl: thumb,
              sourceUrl: sgc,
              mediaType: 1,
              renderLargerThumbnail: true,
            },
          },
        },
        { quoted: fkontak },
      );
    }
  } else {
    await conn.reply(
      m.chat,
      `*[ MENU ${perintah.toUpperCase()} NOT FOUND ]*\n> • _Ketik *.menu* untuk melihat semua kategori menu atau keitk *.menu all* untuk melihat semua fitur_`,
      m,
    );
  }
};

menulist.help = ["menu"].map((a) => a + " *[view main menu]*");
menulist.tags = ["main"];
menulist.command = ["menu"];

module.exports = menulist;

function clockString(ms) {
  let h = isNaN(ms) ? "--" : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? "--" : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? "--" : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(":");
}