//cr bang syai

let handler = async (m, { usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || "";

  if (!mime) throw `*• Example:* ${usedPrefix + command} *[reply/send media]*`;
  try {
    let media = await q.download();
    let link = `*[ UPLOADER ]*
> • *Link:* ${await (
      await require(process.cwd() + "/lib/uploader.js").uploadPomf2(
        await q.download(),
      )
    ).files[0].url}`;
    m.reply(link.trim());
  } catch (e) {
    throw e;
  }
};
handler.help = ["tourl", "upload"].map((a) => a + " *[reply/send media]*");
handler.tags = ["tools"];
handler.command = ["tourl", "upload"];

module.exports = handler;
