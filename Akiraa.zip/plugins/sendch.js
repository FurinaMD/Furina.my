const { generateWAMessageFromContent, proto } = require("akiraa-baileys") 
let handler = async (m, { conn, args }) => {
    const channelId = '120363330588681517@newsletter';
    let pesan = args.join(' ');
    if (!pesan) throw '• *Contoh :* .sendch Hello';
const senderName = m.pushName
    const messages = {
        extendedTextMessage: {
            text: `${pesan}\n\nDikirim oleh: ${senderName}`,
            contextInfo: {
isForwarded: true, 
 forwardedNewsletterMessageInfo: {
 newsletterJid: '120363330588681517@newsletter',
 newsletterName: 'Powered By Fakrul',
 serverMessageId: -1
},
                externalAdReply: {
                    body: 'powered by Fakrul',
                    mediaType: 1,
                    renderLargerThumbnail: false,
                    thumbnailUrl: 'https://telegra.ph/file/3a34bfa58714bdef500d9.jpg',
                    sourceUrl: 'https://whatsapp.com/channel/0029VahdkpZ6GcGO29mUq51f'
                }
            }
        }
    };

    const messageToChannel = proto.Message.encode(messages).finish();
    const result = {
        tag: 'message',
        attrs: { to: channelId, type: 'text' },
        content: [
            {
                tag: 'plaintext',
                attrs: {},
                content: messageToChannel
            }
        ]
    };

    await conn.query(result);

    m.reply(`Berhasil Mengirim:\nPesan: ${pesan}\ntarget: Channel ${channelId}`);
};

handler.help = ['sendch *<text>*'];
handler.tags = ['owner'];
handler.command = /^(sendch)$/i;
handler.owner = true;

module.exports = handler;