let handler = async (m, { conn, command, text }) => {
	
    if (!text) return conn.reply(m.chat, '• *Example :* .cekbapak udin', m)
	
  conn.reply(m.chat, `
╭━━━━°「 *BAPAK ${text}* 」°
┊• Nama : ${text}
┃• Bapaknya : ${pickRandom(['jamal','markona','budi','dimas','sawaludin','jalaludin','markona','rafi ahmad','roy kiyoshi','bambang','darwani','darwin','kopet','jono','joni','atta','thorik','ragil','vinsen', 'udin','winda basudara','mr ambatukam','gerald Vincen','rizzpiw','rioo','permenmd','dhan','luh dikick dari kk'])}
╰═┅═━––––––๑
`.trim(), m)
}
handler.help = ['cekbapak *<name>*']
handler.tags = ['fun']
handler.command = /^cekbapak/i

module.exports = handler

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)]
}
