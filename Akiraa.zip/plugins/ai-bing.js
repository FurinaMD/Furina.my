const handler = async (m, { conn, args, usedPrefix, command }) => {
  let text;
  if (args.length >= 1) {
    text = args.slice(0).join(" ");
  } else if (m.quoted && m.quoted.text) {
    text = m.quoted.text;
  } else {
    throw "*• Example:* .bingimg 1girl";
  }

  await m.reply("Please wait...");
  try {
    const res = new Scraper.Ai.Bingimg({
      cookie: `1XSaEQUbrjuENyoaQloPCXsY8NNCjEwMqQEAWVcfv6uFthDrmeOgH29YfhGp3LKwzSKeFF1D2g2mCk_6mNeU7XVHK0h2PxpY26IBPkKbxaMsqU5A3XxtcfzyKoTPvJDaOmpuZRmol0mdNhRIjaPc9yoaD7AwVXI64qjxENRzDw3y_VXNIgS9twaURiWawc_VQGU7Ge9igDHEwa96qyrxbOxZLm5UIww6WnJEgA8F6KD0`,
    });
    const data = await res.createImage(text);

    if (data.length > 0) {
      for (let i = 0; i < data.length; i++) {
        try {
          if (!data[i].endsWith(".svg")) {
            await conn.sendFile(
              m.chat,
              data[i],
              "",
              `Image *(${i + 1}/${data.length})*\n\n*Prompt*: ${text}`,
              m,
              false,
              {
                mentions: [m.sender],
              },
            );
          }
        } catch (error) {
          console.error(`Error sending file: ${error.message}`);
          await m.reply(`Failed to send image *(${i + 1}/${data.length})*`);
        }
      }
    } else {
      await m.reply("No images found.");
    }
  } catch (error) {
    console.error(`Error in handler: ${error.message}`);
    await m.reply(`${error}\n\n${error.message}`);
  }
};

handler.help = ["bingimg"].map((a) => a + " *[prompt]*");
handler.tags = ["ai"];
handler.command = ["bingimg"];
handler.register = true;
handler.premium = true;

module.exports = handler;
