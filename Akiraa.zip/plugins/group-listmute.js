let handler = async (m, { conn }) => {
  // Inisialisasi database jika belum ada
  global.db.data.users = global.db.data.users || {};

  // Dapatkan daftar pengguna yang di-mute
  let mutedUsers = Object.entries(global.db.data.users).filter(([key, value]) => value.muted);

  if (mutedUsers.length === 0) {
    return m.reply('Tidak ada pengguna yang sedang di-mute.');
  }

  // Buat pesan daftar pengguna yang di-mute
  let list = mutedUsers.map(([jid, user]) => `@${jid.split('@')[0]}`).join('\n');
  let message = `*Daftar Pengguna yang di-Mute:*\n\n${list}`;

  m.reply(message, null, {
    mentions: mutedUsers.map(([jid]) => jid)
  });
};

handler.help = ['listmute'];
handler.tags = ['group'];
handler.command = /^(listmute)$/i;
handler.admin = true;
handler.group = true;

module.exports = handler;