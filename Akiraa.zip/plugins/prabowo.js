const Logic = `Perkenalkan nama saya prabowo Subinto

Deskripsi Tentang dirimu : 
Letnan Jenderal TNI (Purn.) H. Prabowo Subianto Djojohadikusumo adalah anak ketiga dan putra pertama yang lahir pada tanggal 17 Oktober 1951. Ayahnya bernama Soemitro Djojohadikusumo, seorang begawan ekonomi, dan ibunya bernama Dora Sigar. Prabowo Subianto adalah adik ipar dari Presiden Soeharto, yang memerintah Indonesia dari tahun 1967 hingga 1998.

Prabowo Subianto memulai karir militernya pada tahun 1974 setelah lulus dari Akademi Militer Nasional. Ia pernah menjabat sebagai komandan Kopassus dari tahun 1995 hingga 1998. Setelah Orde Baru runtuh, Prabowo Subianto pensiun dari militer dan terjun ke dunia politik.

Pada tahun 2004, Prabowo Subianto mendirikan Partai Gerindra. Ia mencalonkan diri sebagai presiden pada pemilihan presiden tahun 2009 dan 2014, namun kalah dari Susilo Bambang Yudhoyono dan Joko Widodo.

Pada tahun 2019, Prabowo Subianto ditunjuk oleh Presiden Joko Widodo sebagai Menteri Pertahanan. Ia merupakan menteri pertahanan pertama yang berasal dari latar belakang militer sejak era Orde Baru.`;

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!db.data.msgs[m.sender]) {
    db.data.msgs[m.sender] = [];
  }
  if (!text) throw `Mau Nanya apa?`;

  const messages = [
    {
      role: "system",
      content: Logic,
    },
    {
      role: "user",
      content: text,
    },
  ];
  const { data } = await axios.post(
    "https://deepenglish.com/wp-json/ai-chatbot/v1/chat",
    {
      messages,
    },
  );
  conn.sendMessage(m.chat, {
    audio: {
      url: `https://ai.xterm.codes/api/text2speech/elevenlabs?text=${data.answer}&key=Bell409&voice=prabowo`,
    },
    mimetype: "audio/mpeg",
    contextInfo: {
      externalAdReply: {
        title: "AI - PRABOWO",
        body: "Ai with Probowo voice",
        mediaType: 1,
        thumbnailUrl: "https://files.catbox.moe/nmuenp.jpg",
        renderLangerThumbnail: true,
      },
    },
  });
};
handler.help = ["aiprabowo", "prabowo"].map((a) => a + " *[question]*");
handler.tags = ["ai"];
handler.command = ["aiprabowo", "prabowo"];

module.exports = handler;
