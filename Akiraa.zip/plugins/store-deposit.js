//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6287869975929,6283831945469

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

//© AkiraaBot 2023-2024
// • Credits : wa.me/6287869975929 [ Bang syaii ]
// • Owner: 6283831945469,6287869975929

/*
• untuk siapa pun yang ketahuan menjual script ini tanpa sepengetahuan developer mohon untuk dilaporkan !
*/

const axios = require("axios");
const FormData = require("form-data");

let handler = async (m, { conn, text, usedPrefix, command }) => {
  let isProcess = false;
  if (!text) throw `*• Example :* ${usedPrefix} ${command} *[amount]*`;
  let amount = text.split(" ")[0];
  let metode = text.slice(amount.length + 1);
  if (isNaN(amount)) throw "*[ System notice ]* Masukkan angka, bukan huruf";
  var conf = new FormData();
  if (!metode) {
    conf.append("key", maupedia.key);
    conf.append("sign", maupedia.signature);
    conf.append("secret", maupedia.secret);
    conf.append("type", "method");
    var config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "https://maupedia.com/api/deposit",
      headers: {
        ...conf.getHeaders(),
      },
      data: conf,
    };
    let { data } = await axios(config).catch((e) => e?.response);
    if (!data.result) throw "*[ System notice ]* " + data.data.message;
    let arr = [];
    let list = data.data.filter((a) => a.type === "qris");
    for (let i of list) {
      arr.push({
        rows: [
          {
            title: "• " + i.name,
            body: `• Min : ${Func.formatNumber(i.min)}\n• Max : ${Func.formatNumber(i.max)}`,
            command: `${usedPrefix}${command} ${amount} ${i.code}`,
          },
        ],
      });
    }
    conn.sendList(m.chat, "Click Here!", arr, m, {
      body: `*[ System notice ]* Silahkan pilih metode Deposit anda dibawah`,
      footer: `*• Example :* ${usedPrefix}${command} ${amount} *code_method*`,
    });
  } else if (metode === "cancel") {
    conf.append("key", maupedia.key);
    conf.append("sign", maupedia.signature);
    conf.append("secret", maupedia.secret);
    conf.append("type", "cancel");
    conf.append("trxid", amount);
    var config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "https://maupedia.com/api/deposit",
      headers: {
        ...conf.getHeaders(),
      },
      data: conf,
    };
    let response = await axios(config);
    isProcess = true;
    m.reply(response.data.message);
  } else {
    conf.append("key", maupedia.key);
    conf.append("sign", maupedia.signature);
    conf.append("secret", maupedia.secret);
    conf.append("type", "request");
    conf.append("method", metode);
    conf.append("quantity", amount);
    var config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "https://maupedia.com/api/deposit",
      headers: {
        ...conf.getHeaders(),
      },
      data: conf,
    };
    let response = await axios(config);
    let hasil = response.data;
    if (!hasil.result) throw `*[ System notice ]* ${hasil.message}`;
    const qrCodeData = await require("qrcode").toDataURL(
      hasil.data.qr_string.slice(0, 2048),
      {
        scale: 10,
      },
    );
    const buffer = Buffer.from(qrCodeData.substring(22), "base64");
    let cap = `*[ DEPOSIT BY AKIRAABOT ]*
*• Name :* ${hasil.data.name}
*• TrxId :* ${hasil.data.trxid}
*• Status :* ${hasil.data.status.toUpperCase()}
*• Amount :* ${Func.formatNumber(hasil.data.amount)}
*• Fee :* ${hasil.data.fee}
*• Note :* ${hasil.data.pay_note}
*• Checkout :* ${hasil.data.qr_url}
*• Expired at :* 1 Hour

Pindai Qris di Ewallet Anda untuk melanjutkan transaksi deposit

Qris ini dapat digunakan ke semua Ewallet:

* Dana Ewallet 
* Ovo Ewallet 
* Gopay Ewallet
* Shopeepay
* LinkAja
* NusaPay
* BCA Mobile
* BRI.`;
    await conn.sendButton(m.chat, [
    ["Cancel Deposit", `${usedPrefix + command} ${hasil.data.trxid} cancel`]
    ], m, {
    body: cap,
    footer: done,
    url: await Uploader.catbox(buffer)
    })
  
    setTimeout(async() => {
    conf.append("key", maupedia.key);
    conf.append("sign", maupedia.signature);
    conf.append("secret", maupedia.secret);
    conf.append("type", "cancel");
    conf.append("trxid", amount);
    var config = {
      method: "post",
      maxBodyLength: Infinity,
      url: "https://maupedia.com/api/deposit",
      headers: {
        ...conf.getHeaders(),
      },
      data: conf,
    };
    let response = await axios(config);
    isProcess = true;
   await conn.reply(
          m.sender,
          `*[ TRANSAKSI TIMEOUT ]*
*• TrxId :* ${data.data.trxid}
*• Amount :* TIMEOUT

Transaksi Gagal kerena Qris Kedaluarsa !
silahkan lakukan transaksi baru`,
          null,
        );
    }, 3600000)
    while (!isProcess) {
      var data = new FormData();
      data.append("key", maupedia.key);
      data.append("sign", maupedia.signature);
      data.append("secret", maupedia.secret);
      data.append("type", "status");
      data.append("trxid", hasil.data.trxid);

      var config = {
        method: "post",
        maxBodyLength: Infinity,
        url: "https://maupedia.com/api/deposit",
        headers: {
          ...data.getHeaders(),
        },
        data: data,
      };

      let status = await (await axios(config)).data;

      if (status.data[0].status === "paid") {
        let user = global.db.data.users[m.sender];
        isProcess = true;
        console.log("Deposit Berhasil !");
        user.saldo += parseInt(amount);
        await conn.reply(
          m.sender,
          `*[ TRANSAKSI SUCCESS ]*
*• TrxId :* ${status.data[0].trxid}
*• Amount :* ${Func.formatNumber(status.data[0].amount)}
*• Status :* ${status.data[0].status.toUpperCase()}
*• Update at :* ${status.data[0].updated_at}

Saldo Sudah masuk ke akun anda !, Total saldo kamu sekarang *Rp ${Func.formatNumber(user.saldo)}*`,
          null,
        );
      }
    }
  }
};
handler.help = ["deposit"];
handler.tags = ["store"];
handler.command = ["deposit"];

module.exports = handler;
