

var handler = async (m, { conn, text }) => {
if (!text) return m.reply("Masukan query!")
try {
  var { data } = await require("axios")({
    "method": "GET",
    "url": "https://manaxu-seven.vercel.app/api/internet/wikipedia?query=" + text
  })
  var { judul, thumb, isi } = data.result
  let x = `*${judul}*\n\n${isi}`
  conn.sendMessage(m.chat, { image: { url: thumb }, caption: x }, { quoted: m })
} catch (e) {
return m.reply("fitur eror")
}
}
handler.command = handler.help = ["wikipedia"]
handler.tags = ["internet"]

module.exports = handler
