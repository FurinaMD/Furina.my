
const fs = require('fs');
let packageJson = JSON.parse(fs.readFileSync('package.json', 'utf8'));
let version = packageJson.version;

let handler = async (m, { conn }) => {
  conn.reply(m.chat, `Silvia -  MD: VERSION *${global.version}*`, m, {
    contextInfo: {
      externalAdReply: {
        title: `${global.namebot}`,
        body: "",
        thumbnailUrl: "https://telegra.ph/file/18e7bc8b149917d645f18.jpg",
        sourceUrl: "https://whatsapp.com/channel/0029VahdkpZ6GcGO29mUq51f",
        mediaType: 1,
        renderLargerThumbnail: true
      }
    }
  });
};

handler.command = ['version'];
handler.help = ['version'];
handler.tags = ['info'];

module.exports = handler;
