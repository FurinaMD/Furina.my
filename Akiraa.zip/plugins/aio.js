const fetch = require('node-fetch')
let handler = async (m, { conn, usedPrefix, command, text }) => {
if (!text) return m.reply(`• *Example :* ${usedPrefix}${command} *[url]*`)
m.reply(wait)
let res = await fetch(`https://api.kyuurzy.site/api/download/aio?query=${text}`)
let hasil = await res.json()
await conn.sendFile(m.chat, hasil.result.url, '', '', m)
}
handler.help = ["aio"].map((a) => a + " *[url]*");
handler.tags = ["downloader"];
handler.command = ["aio"];
handler.limit = 1;
module.exports = handler;