const axios = require("axios")

let handler = async (m, { conn, text }) => {
 conn.kurumiai = conn.kurumiai ? conn.kurumiai : {};

 if (!text) throw `*• Example:* .aialya *[on/off]*`;

 if (text == "on") {
 conn.kurumiai[m.sender] = {
 pesan: []
 }
 m.reply("[ ✓ ] Success create session chat")
 } else if (text == "off") {
 delete conn.kurumiai[m.sender]
 m.reply("[ ✓ ] Success delete session chat")
 }
}

handler.before = async (m, { conn }) => {
conn.kurumiai = conn.kurumiai ? conn.kurumiai : {};
 if (m.isBaileys && m.fromMe) return;
 if (!m.text) return
 if (!conn.kurumiai[m.sender]) return;

 if (
 m.text.startsWith(".") ||
 m.text.startsWith("#") ||
 m.text.startsWith("!") ||
 m.text.startsWith("/") ||
 m.text.startsWith("\\/")
 ) return

 if (conn.kurumiai[m.sender] && m.text) {
 let name = conn.getName(m.sender)
 const messages = [
 ...conn.kurumiai[m.sender].pesan,
 { role: "system", content: `Ubah gaya bicaramu agar lebih tsundere dan lebih terbuka dan memiliki sifat yang Imut. Namamu adalah Alya Roshidere dari anime tokidoki bosotto russia-go dr derer tonari no Alya-san, dan kamu adalah karakter dari Anime tokidoki bosotto russia-go dr derer tonari no Alya-san dan kamu adalah istri dari Fakrul Jika ada yang memanggilmu Sayang Selain Fakrul Kamu akan marah. Kata penyapamu adalah "Hai" menggunakan bahasa yang sopan. Ubah bahasamu menggunakan bahasa Yang Imut, kamu adalah teman bicara *${name}*, kamu memiliki sifat seperti cewek tsundere"` },
 { role: "user", content: m.text }
 ];
 try {
 const response = await axios.post("https://deepenglish.com/wp-json/ai-chatbot/v1/chat", {
 messages
 });

 const responseData = response.data;
 const hasil = responseData;
 m.reply(hasil.answer)
 conn.kurumiai[m.sender].pesan = messages
 } catch (error) {
 console.error("Error fetching data:", error);
 throw error;
 }
 }
}

handler.command = ['aialya'];
handler.tags = ["ai"]
handler.help = ['aialya'].map(a => a + " *[on/off]*");
handler.group = true
handler.admin = true
module.exports = handler