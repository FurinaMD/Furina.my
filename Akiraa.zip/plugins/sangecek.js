let handler  = async (m, { conn }) => {
  conn.reply(m.chat,`“${pickRandom(sange)}”`, m)
}
handler.help = ['sangecek']
handler.tags = ['fun']
handler.command = /^(sangecek|ceksange)$/i

module.exports = handler 

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())]
}

const sange = [
'🥵 Sange Level : 100%\n\nJIR SEBAIKNYA CEPET CEPET SEWA',
'🥵 Sange Level : 100%\n\nJIR.... SEBAIKNYA SEGERA SEWA' ,
'🥵 Sange Level : 100%\n\nKAK?!??.... SANGE!?.. SEWA YG 100K PERJAM AJA 🥵',
'🥵 Sange Level : 1000%\n\nKAK.?? AYO NGEWE 😳',
'🥵 Sange Level : 86%\n\nKAK??? KALO SANGE COLMEK/NGOCOK AJA 🥰',
'🥵 Sange Level : 51%\n\nLu setengah sange, jadi cukup nonton bokep aja 🤏',
'🥵 Sange Level : 67%\n\nNonton hentai kak kalo sange 🥵',
'🥵 Sange Level : 46%\n\nMasih bisa ditahan kak semangat ☺️',
'🥵 Sange Level : 34%\n\nDikit lah, paling pegang² anu doang 🤏',
'🥵 Sange Level : 27%\n\nSange dikit lah ya',
'🥵 Sange Level : 16%\n\nAman 🙏',
'🥵 Sange Level : 14%\n\nFiuh.. Kakak aman',
'🥵 Sange Level : 7%\n\nKakak ga sange 🤗',
'🥵 Sange Level : 4%\n\nNormal',
'🥵 Sange Level : 0%\n\nSange? ngocok/colmek pun kakak ga pernah 😊',
]