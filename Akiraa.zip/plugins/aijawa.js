const fetch = require("node-fetch");
var handler = async (m, { text, usedPrefix, command }) => {
	if (!text) throw `tanyakan saja kepada ai? `;
	try {
		const { key } = await conn.sendMessage(
			m.chat,
			{ text: "Tunggu sebentar..." },
			{ quoted: m },
		);
		var apii = await fetch(
			`https://skizo.tech/api/openai?apikey=${global.xzn}&text=${text}&system=kamu adalah ai yang bisa bahasa Jawa,dan jika pertanyaannya bahasa Indonesia,kamu jawab bahasa Jawa,ingat!!,dan setiap jawaban selalu ada wemoji,dan saya ingatkan lagi KAMU SETIAP JAWABANNYA PAKAI BAHASA JAWA!!`,
		);
		var res = await apii.json();

		await conn.sendMessage(
			m.chat,
			{ text: "*[ AIJAWA ]* " + "\n" + res.result, edit: key },
			{ quoted: m },
		);
	} catch (err) {
		console.error(err);
		throw "Terjadi kesalahan dalam menjawab pertanyaan";
	}
};
handler.help = ["aijawa *ᴛᴇxᴛ*"];
handler.tags = [tai];
handler.command = /^(aijawa)$/i;
module.exports = handler;