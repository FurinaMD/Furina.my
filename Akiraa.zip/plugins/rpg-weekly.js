const rewards = {
  exp: 15000,
  money: 35999,
  potion: 9,
};
const cooldown = 604800000;
let handler = async (m) => {
  let user = global.db.data.users[m.sender];
  if (new Date() - user.lastweekly < cooldown)
    throw `You have already claimed this daily claim!`;
  let text = "";
  for (let reward of Object.keys(rewards)) {
    if (!(reward in user)) continue;
    user[reward] += rewards[reward];
    text += `*+${rewards[reward]}* ${global.rpg.emoticon(reward)}${reward}\n`;
  }
  conn.sendButton(
    m.chat,
    [
      ["Inventory", ".inv"],
      ["Monthly", ".monthly"],
    ],
    m,
    { body: "*––––––『 WEEKLY 』––––––*", footer: text.trim() },
  );
  user.lastweekly = new Date() * 1;
};
handler.help = ["weekly"];
handler.tags = ["rpg"];
handler.command = /^(weekly)$/i;
handler.cooldown = cooldown;

module.exports = handler;
