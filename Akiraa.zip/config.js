let { Scraper, Uploader } = require("akiraa-wb");
let fs = require("fs");
let fetch = require("node-fetch");
let moment = require("moment-timezone");
let cp = require("child_process");
let { promisify } = require("util");
let scrap = require(process.cwd() + "/scrape");
//Apikey
global.rose =  "J8rLad2TXRKdqfVC3ToqxJy5zEqmtzI3b5y6yjzC1IIYAXl7hfhWoxtU9siJ4GU6";
global.lolhuman = "Akiraa";
global.lolkey = 'gatadiosv2'
global.btc = 'raffxsukatobrut'
global.lann = 'fahri-hosting'
global.skizo = 'Twelve'
//URL THUMBNAIL
global.gif = "https://pomf2.lain.la/f/stk6lwhd.mp4"; //Ini buat gif yang di menu
global.icon = "https://telegra.ph/file/18e7bc8b149917d645f18.jpg";
global.thumb = "https://telegra.ph/file/18e7bc8b149917d645f18.jpg";
//URL
global.sgc = "https://whatsapp.com/channel/0029VahdkpZ6GcGO29mUq51f";
global.sourceUrl = "https://github.com/fahrihostingg";
global.sig = "https://www.instagram.com/rulshz/";
//SET MENU
global.menu = "button";
//
global.owner = ["601159754638"];
global.mods = ["601159754638"]; // Moderator
global.prems = ["601159754638"]; // Premium
// YANG ATAS ITU UBAH JADI NOMOR LU
// & YG BAWAH INI, NOMOR,NAMA,EMAIL LU
global.fsizedoc = "45000000000"; // default 10TB
global.fpagedoc = "19";
global.numberbot = "601159754638";
global.namedoc = "Silvia Bot Whatsapp Multi device";
global.nameowner = "Fakrul";
global.nomorown = "601159754638";

/*=====[ PAYMENT SETTING ]==========*/
global.dana = "083844082339"; //kalo ga punya ubah jadi "-" aja
global.gopay = "-";
global.ovo = "-";
global.saweria = "https://saweria.co/xxxxx";
/*====[ PAYMENT SETTING ]==========*/
global.namebot = "Silvia - MD";
global.swa = "wa.me/601159754638";
global.wm = "Silvia MD 2022-2024";
global.watermark = wm;
global.wm2 = "Silvia MD";
global.wm3 = namebot;
global.idgc = "120363205224900648@g.us"; //isi pake id gc lu
global.isPairing = true;
global.wm4 = namebot;
global.fla =
  "https://flamingtext.com/net-fu/proxy_form.cgi?&imageoutput=true&script=water-logo&script=water-logo&fontsize=90&doScale=true&scaleWidth=800&scaleHeight=500&fontsize=100&fillTextColor=%23000&shadowGlowColor=%23000&backgroundColor=%23000&text=";
global.wait = "*⫹⫺ PLEASE WAIT...*";
global.eror = "*⫹⫺ SYSTEM ERROR...*";
global.done = "```Silvia Multidevice```";
global.salah = "Salah\n";
global.web = global.sourceUrl;
global.packname = "┌─⭓「Sticker by Silvia MD」\n│Owner : Fakrul\n│Ig https://www.instagram.com/rulshz\n│github https://github.com/fahrihostingg\n└────────────⭓";
global.author = ``;
global.version = "V6.0";
global.multiplier = 100;
global.rpg = {
  emoticon(string) {
    string = string.toLowerCase();
    let emot = {
      exp: "✉️",
      money: "💵",
      potion: "🥤",
      diamond: "💎",
      common: "📦",
      uncommon: "🎁",
      mythic: "🗳️",
      legendary: "🗃️",
      pet: "🎁",
      sampah: "🗑",
      armor: "🥼",
      sword: "⚔️",
      kayu: "🪵",
      batu: "🪨",
      string: "🕸️",
      kuda: "🐎",
      kucing: "🐈",
      anjing: "🐕",
      petFood: "🍖",
      gold: "👑",
      emerald: "💚",
    };
    let results = Object.keys(emot)
      .map((v) => [v, new RegExp(v, "gi")])
      .filter((v) => v[1].test(string));
    if (!results.length) return "";
    else return emot[results[0][0]];
  },
};
global.doc = pickRandom([
  "application/vnd.ms-excel",
  "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  "application/msword",
  "application/pdf",
]);
global.fetch = require("node-fetch");
global.Func = new (require(process.cwd() + "/lib/func"))();
// global.botdate = b.tanggal(new Date());
global.axios = require("axios");
global.Uploader = Uploader;
global.cheerio = require("cheerio");

const _uptime = process.uptime() * 1000;

global.fkontak = {
  key: {
    remoteJid: "0@s.whatsapp.net",
    participant: "0@s.whatsapp.net",
    id: "",
  },
  message: {
    conversation: `*Silvia MultiDevice*`,
  },
};
global.tanggal = async (numer) => {
  const myMonths = [
    "Januari",
    "Februari",
    "March",
    "April",
    "Mei",
    "June",
    "Julai",
    "August",
    "September",
    "Oktober",
    "November",
    "Desember",
  ];

  const myDays = [
    "Ahad",
    "Isnin",
    "Selasa",
    "Rabu",
    "Khamis",
    "Jumaat",
    "Sabtu",
  ];

  const tgl = new Date(numer);
  const day = tgl.getDate();
  const bulan = tgl.getMonth();
  const thisDay = tgl.getDay();
  const thisDayName = myDays[thisDay];
  const yy = tgl.getYear();
  const year = yy < 1000 ? yy + 1900 : yy;
  const time = require("moment").tz("Asia/Jakarta").format("DD/MM HH:mm:ss");
  const d = new Date();
  const locale = "id";
  const gmt = new Date(0).getTime() - new Date("1 January 1970").getTime();
  const weton = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][
    Math.floor((d * 1 + gmt) / 84600000) % 5
  ];

  return `${thisDayName}, ${day} - ${myMonths[bulan]} - ${year}`;
};
global.fakestatus = (txt) => {
  return {
    key: {
      remoteJid: "0@s.whatsapp.net",
      participant: "0@s.whatsapp.net",
      id: "",
    },
    message: {
      conversation: txt,
    },
  };
};

function pickRandom(list) {
  return list[Math.floor(list.length * Math.random())];
}

let file = require.resolve(__filename);
fs.watchFile(file, () => {
  fs.unwatchFile(file);
  console.log("Update config.js");
  delete require.cache[file];
  require(file);
});
