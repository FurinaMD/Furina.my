(async () => {
  require("./config");
  const { Lib, Store } = require("akiraa-wb");
  const {
    default: makeWASocket,
    useMultiFileAuthState,
    makeInMemoryStore,
    makeCacheableSignalKeyStore,
    DisconnectReason,
    fetchLatestBaileysVersion,
    PHONENUMBER_MCC,
    Browsers,
    proto,
    jidNormalizedUser,
  } = require("akiraa-baileys");
  const WebSocket = require("ws");
  const path = require("path");
  const p = require("pino");
  const pino = require("pino");
  const Pino = require("pino");
  const { Boom } = require("@hapi/boom");
  const fs = require("fs");
  const chokidar = require("chokidar");
  const readline = require("readline");
  const NodeCache = require("node-cache");
  const yargs = require("yargs/yargs");
  const cp = require("child_process");
  const { promisify, format } = require("util");
  const exec = promisify(cp.exec).bind(cp);
  const _ = require("lodash");
  const syntaxerror = require("syntax-error");
  const os = require("os");
  const simple = require("./lib/simple.js");
  const { randomBytes } = require("crypto");
  const moment = require("moment-timezone");
  const chalk = require("chalk");
  const readdir = promisify(fs.readdir);
  const stat = promisify(fs.stat);
  const { smsg, isUrl, generateMessageTag, getBuffer, getSizeMedia, fetchJson, sleep } = require('./lib/myfunc')
  const { color } = Lib.color;
  var low;
  try {
    low = require("lowdb");
  } catch (e) {
    low = require("./lib/lowdb");
  }
  const { Low, JSONFile } = low;
  const randomID = (length) =>
    randomBytes(Math.ceil(length * 0.5))
      .toString("hex")
      .slice(0, length);

  API = (name, path = "/", query = {}, apikeyqueryname) =>
    (name in APIs ? APIs[name] : name) +
    path +
    (query || apikeyqueryname
      ? "?" +
        new URLSearchParams(
          Object.entries({
            ...query,
            ...(apikeyqueryname
              ? {
                  [apikeyqueryname]: APIKeys[name in APIs ? APIs[name] : name],
                }
              : {}),
          }),
        )
      : "");
  timestamp = {
    start: new Date(),
  };

  const PORT = process.env.PORT || 3000;

  global.opts = new Object(
    yargs(process.argv.slice(2)).exitProcess(false).parse(),
  );
  global.prefix = new RegExp(
    "^[" +
      (
        opts["prefix"] ||
        "â€ŽxzXZ/i!#$%+Â£Â¢â‚¬Â¥^Â°=Â¶âˆ†Ã—Ã·Ï€âˆšâœ“Â©Â®:;?&.\\-"
      ).replace(/[|\\{}()[\]^$+*?.\-\^]/g, "\\$&") +
      "]",
  );

  db = new Low(
    /https?:\/\//.test(opts["db"] || "")
      ? new cloudDBAdapter(opts["db"])
      : new JSONFile(`${opts._[0] ? opts._[0] + "_" : ""}database.json`),
  );

  DATABASE = db;
  loadDatabase = async function loadDatabase() {
    if (!db.READ) {
      setInterval(async () => {
        await db.write(db.data || {});
      }, 2000);
    }
    if (db.data !== null) return;
    db.READ = true;
    await db.read();
    db.READ = false;
    db.data = {
      users: {},
      chats: {},
      stats: {},
      msgs: {},
      sticker: {},
      settings: {},
      respon: {},
      ...(db.data || {}),
    };
    db.chain = _.chain(db.data);
  };
  loadDatabase();

  global.authFolder = `sessions`;
  const logger = pino({
    timestamp: () => `,"time":"${new Date().toJSON()}"`,
  }).child({ class: "Silvia" });
  logger.level = "fatal";

  global.store = makeInMemoryStore({
    logger: pino().child({
      level: "silent",
      stream: "store",
    }),
  });

  function createTmpFolder() {
    const folderName = "tmp";
    const folderPath = path.join(__dirname, folderName);
    if (!fs.existsSync(folderPath)) {
      fs.mkdirSync(folderPath);
      console.log(
        chalk.green.bold(`[ Success ] Folder '${folderName}' berhasil dibuat.`),
      );
    } else {
      console.log(
        chalk.blue.bold(`[ Exists ] Folder '${folderName}' already exists.`),
      );
    }
  }
  createTmpFolder();
  
  const { state, saveState, saveCreds } =
    await useMultiFileAuthState(authFolder);
  const msgRetryCounterMap = (MessageRetryMap) => {};
  const msgRetryCounterCache = new NodeCache();
  const { version } = await fetchLatestBaileysVersion(); 
  const question = (text) => {
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
return new Promise((resolve) => {
rl.question(text, resolve)
})
};
  async function keyoptions(url, options) {
    try {
        const methodskey = await axios({
            method: "GET",
            url: url,
            headers: {
                'User-Agent': "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/95.0.4638.69 Safari/537.36"
            },
            ...options
        });
        return methodskey.data;
    } catch (err) {
        return err;
    }
}
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
    let systemkeyy = false;
    if (systemkeyy === false) {
        let xkey;
        if (global.pw) {
            xkey = global.pw;
        } else {
            console.log(chalk.cyan.bold("Masuk Key Nya :"));
            
            xkey = await question(chalk.yellow(""));
        }
        //Akses key/password 
        setTimeout(async () => {
      const buff = Buffer.from("aHR0cHM6Ly9yYXcuZ2l0aHVidXNlcmNvbnRlbnQuY29tL0FsaWZhdGFoZmF1emkvRmF1emlhbGlmYXRhaC9tYWluL0tleXk=", 'base64').toString("utf-8");
            let mek = await keyoptions(buff);
            if (mek.key !== xkey) {
                const errkey = { text: "Key Tidak Ada Di Dalam Database Kami" };
                spinnies.add("spinner-2", errkey);
                setTimeout(() => {
                    spinnies.fail('spinner-2', { text: "Silahkan di coba lagi" });
                }, 1000);
                await sleep(1000);
                systemkeyy = false;
                process.exit();
            } else {
                spinnies.add("spinner-1", { text: "System sedang Nomor yang kamu masukin." });
                setTimeout(() => {
                    const succeskey = { text: "Akses Key Di Berikan" };
                    spinnies.succeed("spinner-1", succeskey);
                }, 1000);
                systemkeyy = true;
            }
        }, 1000);
       await sleep(3000);
        if (systemkeyy === false) { false }
        rl.close();
    }  
  store.readFromFile(process.cwd() + `/${global.authFolder}/store.json`);

  const connectionOptions = {
    logger: pino({
      level: "silent",
    }),
    printQRInTerminal: !isPairing,
    browser: Browsers.ubuntu("Edge"),
    patchMessageBeforeSending: (message) => {
      const requiresPatch =
        message.buttonsMessage ||
        message.templateMessage ||
        message.listMessage;
      if (requiresPatch) {
        message = {
          viewOnceMessage: {
            message: {
              messageContextInfo: {
                deviceListMetadataVersion: 2,
                deviceListMetadata: {},
              },
              ...message,
            },
          },
        };
      }
      return message;
    },
    version: [2, 3000, 1015901307],
    auth: {
      creds: state.creds,
      keys: makeCacheableSignalKeyStore(
        state.keys,
        pino({
          level: "fatal",
        }).child({
          level: "fatal",
        }),
      ),
    },
    markOnlineOnConnect: true, // set false for offline
    generateHighQualityLinkPreview: true, // make high preview link
    getMessage: async (key) => {
      if (store) {
        const msg = await store.loadMessage(key.remoteJid, key.id);
        return msg.message || undefined;
      }
      return {
        conversation: "Silvia || by Fakrul",
      };
    },
    msgRetryCounterCache,
    defaultQueryTimeoutMs: undefined,
  };
  global.conn = simple.makeWASocket(connectionOptions);
  store.bind(conn.ev);

  if (isPairing && !conn.authState.creds.registered) {
    console.log(
      chalk.blue.bold(
        "[ Question ] Enter your WhatsApp number, example: 628****",
      ),
    );
    const phoneNumber = await question(
      chalk.green.bold(chalk.blue.bold("=> Your Number : ")),
    );
    const code = await conn.requestPairingCode(phoneNumber);
    console.log(
      chalk.green.bold(
        "[ Success ] Your Pairing Code : " +
          code?.match(/.{1,4}/g)?.join("-") || code,
      ),
    );
  }
  async function connectionUpdate(update) {
    const { connection, lastDisconnect, isNewLogin } = update;
    global.stopped = connection;
    if (isNewLogin) conn.isInit = true;
    if (update.qr != 0 && update.qr != undefined) {
    }
    if (connection == "open") {
      console.log(
        chalk.yellow.bold(
          `[ Success ] Success connect to : ${JSON.stringify(conn.user, null, 2)}`,
        ),
      );
    }
    let reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
    if (connection === "close") {
      if (reason === DisconnectReason.badSession) {
        conn.logger.error(
          `Bad Sessions !,  delete ${global.authFolder} and connect again`,
        );
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.connectionClosed) {
        conn.logger.warn(`Connection closed, reconnect...`);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.connectionLost) {
        conn.logger.warn(`Connection lost`);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.connectionReplaced) {
        conn.logger.error(`Connection replace`);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.loggedOut) {
        conn.logger.error(
          `Connection Logout, please delete & create your sessions`,
        );
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.restartRequired) {
        conn.logger.info(`Reastart required, plese wait...`);
        console.log(reloadHandler(true));
      } else if (reason === DisconnectReason.timedOut) {
        conn.logger.warn(`Connection Timeout`);
        console.log(reloadHandler(true));
      } else {
        conn.logger.warn(
          `Connection close ${reason || ""}: ${connection || ""}`,
        );
        console.log(reloadHandler(true));
      }
    }
    if (update.receivedPendingNotifications) {
      const deviceName = os.hostname();
      const message = `┌─⭓「 *Conenction open* 」
│ *• Time :* ${moment.tz("Asia/Makassar").tz("Asia/Jakarta").format("HH:mm:ss")}
│ *• Name :* ${conn.user.name}
│ *• number :* @${conn.user.jid.split("@")[0]}
│ *• Connection With :* *[ ${global.isPairing ? "Pairing Code" : "Qr Code"} ]*
│ *• Owner :* *[ ${owner.map((a) => "@" + a).join(", ")} ]*
└───────────────⭓`;

      await conn.sendList(
        "601159754638@s.whatsapp.net",
        "Q U I C K - S T A R T",
        [
          {
            rows: [
              {
                title: "Menu bot",
                body: "Display menu bot",
                command: ".menu",
              },
              {
                title: "Server Info",
                body: "Display info server",
                command: ". ping",
              },
            ],
          },
        ],
        null,
        {
          body: message,
          footer: "Thank you for purchasing this script !",
          url: await conn.profilePictureUrl(conn.user.jid, "image"),
        },
      );
    }
  }
  process.on("uncaughtException", console.error);
  let isInit = true,
    handler = require("./handler");
  reloadHandler = function (restatConn) {
    let Handler = require("./handler");
    if (Object.keys(Handler || {}).length) handler = Handler;
    if (restatConn) {
      try {
        conn.ws.close();
      } catch {}
      conn = {
        ...conn,
        ...simple.makeWASocket(connectionOptions),
      };
    }
    if (!isInit) {
      conn.ev.off("messages.upsert", conn.handler);
      conn.ev.off("group-participants.update", conn.onParticipantsUpdate);
      conn.ev.off("connection.update", conn.connectionUpdate);
      conn.ev.off("creds.update", conn.credsUpdate);
    }

    conn.welcome =
      "Welcome to *@subject* @user\nSemoga betah Dan jangan lupa baca deskripsi";
    conn.bye = "Goodbye @user,\nSemoga tenang di alam sana.";
    conn.spromote = "@user telah naik jabatan";
    conn.sdemote = "@user telah turun jabatan🗿";
    conn.handler = handler.handler.bind(conn);
    conn.onParticipantsUpdate = handler.participantsUpdate.bind(conn);
    conn.connectionUpdate = connectionUpdate.bind(conn);
    conn.credsUpdate = saveCreds.bind(conn);

    conn.ev.on("messages.upsert", conn.handler);
    conn.ev.on("group-participants.update", conn.onParticipantsUpdate);
    conn.ev.on("connection.update", conn.connectionUpdate);
    conn.ev.on("creds.update", conn.credsUpdate);
    conn.ev.on("groups.update", (updates) => {
      for (const update of updates) {
        const id = update.id;
        if (store.groupMetadata[id]) {
          store.groupMetadata[id] = {
            ...(store.groupMetadata[id] || {}),
            ...(update || {}),
          };
        }
      }
    });
    isInit = false;
    return true;
  };
  console.log(chalk.blue.bold("[ Process ] Load File in Directory plugins"));

  global.plugins = {};

  let Scandir = async (dir) => {
    let subdirs = await readdir(dir);
    let files = await Promise.all(
      subdirs.map(async (subdir) => {
        let res = path.resolve(dir, subdir);
        return (await stat(res)).isDirectory() ? Scandir(res) : res;
      }),
    );
    return files.reduce((a, f) => a.concat(f), []);
  };

  try {
    let files = await Scandir("./plugins");
    let plugins = {};
    for (let filename of files.map((a) => a.replace(process.cwd(), ""))) {
      try {
        plugins[filename] = require(path.join(process.cwd(), filename));
      } catch (e) {
        console.log(chalk.red.bold(e));
        delete plugins[filename];
      }
    }
    const watcher = chokidar.watch(path.resolve("./plugins"), {
      persistent: true,
      ignoreInitial: true,
    });
    watcher
      .on("add", async (filename) => {
        console.log(
          chalk.green.bold(
            "[ New ] Detected New Plugins : " +
              filename.replace(process.cwd(), ""),
          ),
        );
        plugins[filename.replace(process.cwd(), "")] = require(filename);
      })
      .on("change", async (filename) => {
        if (
          require.cache[filename] &&
          require.cache[filename].id === filename
        ) {
          plugins[filename.replace(process.cwd(), "")] =
            require.cache[filename].exports;
          console.log(
            chalk.blue.bold(
              "[ Change ] Changes code in Plugins : " +
                filename.replace(process.cwd(), ""),
            ),
          );
          delete require.cache[filename];
        }
        let err = syntaxerror(
          fs.readFileSync(filename),
          filename.replace(process.cwd(), ""),
        );
        if (err)
          conn.logger.error(`syntax error while loading '${filename}'\n${err}`);
        plugins[filename.replace(process.cwd(), "")] = require(filename);
      })
      .on("unlink", (filename) => {
        console.log(
          chalk.yellow.bold(
            "[ Delete ] Suucess Delete : " +
              filename.replace(process.cwd(), ""),
          ),
        );
        delete plugins[filename.replace(process.cwd(), "")];
      });
    plugins = Object.fromEntries(
      Object.entries(plugins).sort(([a], [b]) => a.localeCompare(b)),
    );
    global.plugins = plugins;
    console.log(
      chalk.green.bold(
        `[ Success ] Success Load ${Object.keys(plugins).length} plugins`,
      ),
    );
  } catch (e) {
    console.error(e);
  }
  global.lib = {};
  let files = await Scandir("./lib");
  for (let filename of files.map((a) => a.replace(process.cwd(), ""))) {
    try {
      lib[filename.split("/lib/")[1].split(".js")[0]] = require(
        path.join(process.cwd(), filename),
      );
    } catch (e) {
      delete lib[filename];
    }
  }
  setInterval(async () => {
    store.writeToFile(process.cwd() + `/${global.authFolder}/store.json`);
  }, 10 * 1000);

  reloadHandler();
})();

function pickRandom(list) {
  return list[Math.floor(Math.random() * list.length)];
}
