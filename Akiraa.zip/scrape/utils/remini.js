const _0xb2e079 = _0x3c0c;
(function (_0x1ca709, _0x2cdcf7) {
  const _0x3c288e = _0x3c0c,
    _0x297b05 = _0x1ca709();
  while (!![]) {
    try {
      const _0x310d89 =
        (parseInt(_0x3c288e(0x89)) / 0x1) * (-parseInt(_0x3c288e(0x85)) / 0x2) +
        -parseInt(_0x3c288e(0x86)) / 0x3 +
        (parseInt(_0x3c288e(0x9b)) / 0x4) * (parseInt(_0x3c288e(0x9c)) / 0x5) +
        (-parseInt(_0x3c288e(0x83)) / 0x6) *
          (-parseInt(_0x3c288e(0x82)) / 0x7) +
        (-parseInt(_0x3c288e(0x8c)) / 0x8) * (parseInt(_0x3c288e(0x93)) / 0x9) +
        parseInt(_0x3c288e(0x91)) / 0xa +
        parseInt(_0x3c288e(0x8a)) / 0xb;
      if (_0x310d89 === _0x2cdcf7) break;
      else _0x297b05["push"](_0x297b05["shift"]());
    } catch (_0x1ae20a) {
      _0x297b05["push"](_0x297b05["shift"]());
    }
  }
})(_0x3ba2, 0xd8ffe);
const FormData = require("form-data"),
  Jimp = require(_0xb2e079(0x9a));
function _0x3c0c(_0x3ad7b0, _0x22b169) {
  const _0x3ba23a = _0x3ba2();
  return (
    (_0x3c0c = function (_0x3c0c30, _0x3f81b6) {
      _0x3c0c30 = _0x3c0c30 - 0x7f;
      let _0xdcb210 = _0x3ba23a[_0x3c0c30];
      return _0xdcb210;
    }),
    _0x3c0c(_0x3ad7b0, _0x22b169)
  );
}
function _0x3ba2() {
  const _0x33f716 = [
    "inferenceengine",
    "push",
    "21AoSGqU",
    "225006xOkcNu",
    "concat",
    "472390FPofBK",
    "4809828vvqtte",
    "data",
    "model_version",
    "3NUOcvQ",
    "14047187eKUyBb",
    "error",
    "3013792ZhnCJd",
    "okhttp/4.9.3",
    ".ai/",
    "enhance_image_body.jpg",
    "from",
    "10610670esKiBu",
    "append",
    "18nRsxLl",
    "submit",
    "https",
    "image",
    ".vyro",
    "image/jpeg",
    "enhance",
    "jimp",
    "24448HhNNWt",
    "1230ttmiGH",
    "Keep-Alive",
  ];
  _0x3ba2 = function () {
    return _0x33f716;
  };
  return _0x3ba2();
}
async function remini(_0xf2c418, _0x58556e) {
  return new Promise(async (_0x2114b8, _0x488180) => {
    const _0x3e75c9 = _0x3c0c;
    let _0x4e714a = [_0x3e75c9(0x99), "recolor", "dehaze"];
    _0x4e714a["includes"](_0x58556e)
      ? (_0x58556e = _0x58556e)
      : (_0x58556e = _0x4e714a[0x0]);
    let _0x7e64bd,
      _0x41e6b7 = new FormData(),
      _0x4da6db =
        _0x3e75c9(0x95) +
        "://" +
        _0x3e75c9(0x80) +
        _0x3e75c9(0x97) +
        _0x3e75c9(0x8e) +
        _0x58556e;
    _0x41e6b7[_0x3e75c9(0x92)](_0x3e75c9(0x88), 0x1, {
      "Content-Transfer-Encoding": "binary",
      contentType: "multipart/form-data;\x20charset=uttf-8",
    }),
      _0x41e6b7[_0x3e75c9(0x92)](
        _0x3e75c9(0x96),
        Buffer[_0x3e75c9(0x90)](_0xf2c418),
        { filename: _0x3e75c9(0x8f), contentType: _0x3e75c9(0x98) },
      ),
      _0x41e6b7[_0x3e75c9(0x94)](
        {
          url: _0x4da6db,
          host: _0x3e75c9(0x80) + _0x3e75c9(0x97) + ".ai",
          path: "/" + _0x58556e,
          protocol: "https:",
          headers: {
            "User-Agent": _0x3e75c9(0x8d),
            Connection: _0x3e75c9(0x7f),
            "Accept-Encoding": "gzip",
          },
        },
        function (_0x3ca9b5, _0x1777a8) {
          const _0x452576 = _0x3e75c9;
          if (_0x3ca9b5) _0x488180();
          let _0x5de6d5 = [];
          _0x1777a8["on"](_0x452576(0x87), function (_0x27a934, _0x2475ec) {
            const _0x4f4864 = _0x452576;
            _0x5de6d5[_0x4f4864(0x81)](_0x27a934);
          })["on"]("end", () => {
            const _0x13ee7f = _0x452576;
            _0x2114b8(Buffer[_0x13ee7f(0x84)](_0x5de6d5));
          }),
            _0x1777a8["on"](_0x452576(0x8b), (_0x3939bf) => {
              _0x488180();
            });
        },
      );
  });
}
module["exports"]["remini"] = remini;
