const axios = require("axios");

async function ragBot(message) {
  try {
    const response = await axios.post(
      "https://ragbot-starter.vercel.app/api/chat",
      {
        messages: [{ role: "user", content: message }],
        useRag: true,
        llm: "gpt-3.5-turbo",
        similarityMetric: "cosine",
      },
    );
    return response.data;
  } catch (error) {
    throw error;
  }
}

module.exports = ragBot;
