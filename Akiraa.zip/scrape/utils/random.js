const axios = require("axios");
const cheerio = require("cheerio");

async function randomCerpen() {
  try {
    const n = await axios.get("http://cerpenmu.com/");
    const a = cheerio.load(n.data);
    let r = [];
    a("#sidebar > div").each(function (t, e) {
      a(e)
        .find("ul > li")
        .each(function (t, e) {
          let n = a(e).find("a").attr("href");
          r.push(n);
        });
    });
    var t = r[Math.floor(Math.random() * r.length)];
    let o = await axios.get(`${t}`);
    const i = cheerio.load(o.data);
    let c = [];
    i("#content > article > article").each(function (t, e) {
      let n = i(e).find("h2 > a").attr("href");
      c.push(n);
    });
    var e = c[Math.floor(Math.random() * c.length)];
    let s = await axios.get(`${e}`);
    let u = cheerio.load(s.data);
    let l = u("#content").find("article > h1").text().trim();
    let h = u("#content").find("article > a:nth-child(2)").text().trim();
    let f = [];
    u("#content > article > p").each(function (t, e) {
      let n = u(e).text().trim();
      f.push(n);
    });
    let w = "";
    for (let t of f) w += t;
    return {
      status: true,
      judul: l,
      penulis: h,
      sumber: e,
      cerita: w,
    };
  } catch (t) {
    return {
      status: false,
    };
  }
}

async function ceritahntu() {
  return new Promise((t, e) => {
    axios
      .get("https://cerita-hantu.com/list-cerita-hantu-a-z/")
      .then(({ data: e }) => {
        const n = cheerio.load(e);
        const a = [];
        n("div > div > ul:nth-child(7) > li > a").each(function (t, e) {
          a.push(n(e).attr("href"));
        });
        n("div > div > ul:nth-child(9) > li > a").each(function (t, e) {
          if (n(e).attr("href") !== null) {
            a.push(n(e).attr("href"));
          }
        });
        n("div > div > ol > li > a").each(function (t, e) {
          if (n(e).attr("href") !== null) {
            a.push(n(e).attr("href"));
          }
        });
        axios
          .get(a[Math.floor(Math.random() * a.length)])
          .then(({ data: e }) => {
            const n = cheerio.load(e);
            const a = [];
            n("div > div > a").each(function (t, e) {
              if (n(e).attr("href").startsWith("https:")) {
                a.push(n(e).attr("href"));
              }
            });
            const rand = a[Math.floor(Math.random() * a.length)];
            axios.get(rand).then(({ data: e }) => {
              const n = cheerio.load(e);
              t({
                judul: n("div > header > div > h1 > a").text(),
                author: n(
                  "div > header > div > div > span.simple-grid-entry-meta-single-author > span > a",
                ).text(),
                author_link: n(
                  "div > header > div > div > span.simple-grid-entry-meta-single-author > span > a",
                ).attr("href"),
                upload_date: n(
                  "div > header > div > div > span.simple-grid-entry-meta-single-date",
                ).text(),
                kategori: n(
                  "div > header > div > div > span.simple-grid-entry-meta-single-cats > a",
                ).text(),
                source: rand,
                cerita: n("div > div > p")
                  .text()
                  .split("Cerita Hantu")[1]
                  .split("Copyright")[0],
              });
            });
          });
      });
  });
}
async function ppcouple() {
  return [
    {
      cowo: "https://telegra.ph/file/ba4d72ea733544f5fc023.jpg",
      cewe: "https://telegra.ph/file/aadca28d43d435b7a0b39.jpg",
    },
    {
      cowo: "https://telegra.ph/file/eaa5ce10338d0c002a487.jpg",
      cewe: "https://telegra.ph/file/d98ad07702074fc8ce268.jpg",
    },
    {
      cowo: "https://telegra.ph/file/3f40bb8b7b64ae91265ad.jpg",
      cewe: "https://telegra.ph/file/1cb5519551de5f7257e44.jpg",
    },
    {
      cowo: "https://telegra.ph/file/49bae59a30c9b9296c59f.jpg",
      cewe: "https://telegra.ph/file/3cdd584a1cd6320270557.jpg",
    },
    {
      cowo: "https://telegra.ph/file/0ceba121fa110fb17b2a6.jpg",
      cewe: "https://telegra.ph/file/4a9c314496c4165882f3c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/9bfed3ec9cfaafda4977a.jpg",
      cewe: "https://telegra.ph/file/d6293842c7a86974bd713.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c798c9058d941d1cfa22e.jpg",
      cewe: "https://telegra.ph/file/84cb8bc51430c403ccfda.jpg",
    },
    {
      cowo: "https://telegra.ph/file/421c675d8b17a78a72df2.jpg",
      cewe: "https://telegra.ph/file/629a721a06eb70ed96465.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b13d543331359cf6ae7a1.jpg",
      cewe: "https://telegra.ph/file/feac0837332d9bc647851.jpg",
    },
    {
      cowo: "https://telegra.ph/file/67640fb70ee5d66fd2f3a.jpg",
      cewe: "https://telegra.ph/file/e397e2a5c09d9202665d9.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f35a1f1dc307fe651f4b8.jpg",
      cewe: "https://telegra.ph/file/35ecdaeb2e1da0ccc163b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f2f7f73aa592e7b82e9f9.jpg",
      cewe: "https://telegra.ph/file/1717bf006c56652148966.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c96ee41f4e9b5506b8ebe.jpg",
      cewe: "https://telegra.ph/file/071a0861995a69300ae12.jpg",
    },
    {
      cowo: "https://telegra.ph/file/5581113fdd503c4f5f532.jpg",
      cewe: "https://telegra.ph/file/1f1482938d326a1feed08.jpg",
    },
    {
      cowo: "https://telegra.ph/file/3eb8fa43c9ae29e7c44cb.jpg",
      cewe: "https://telegra.ph/file/b62f78bbc03ac4cbf55f4.jpg",
    },
    {
      cowo: "https://telegra.ph/file/1a9580891bf94f2f6085f.jpg",
      cewe: "https://telegra.ph/file/2f5ebe9536260a571f19e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/097ecb76b718e5bb36f9f.jpg",
      cewe: "https://telegra.ph/file/2e311240b725344876082.jpg",
    },
    {
      cowo: "https://telegra.ph/file/610b6556e46a28f02d1c5.jpg",
      cewe: "https://telegra.ph/file/6ccace2fe79c718b320f4.jpg",
    },
    {
      cowo: "https://telegra.ph/file/298969f0a157e6d5d7964.jpg",
      cewe: "https://telegra.ph/file/39f2141c0d47ae6a84cfa.jpg",
    },
    {
      cowo: "https://telegra.ph/file/2615604489d851b5d52e1.jpg",
      cewe: "https://telegra.ph/file/8674235b1041c9d6754f9.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7f01d559d6f51aa7fc085.jpg",
      cewe: "https://telegra.ph/file/4c735fd65c10e7c85e8a7.jpg",
    },
    {
      cowo: "https://telegra.ph/file/57b00412e4ae73d50fc3c.jpg",
      cewe: "https://telegra.ph/file/a9fef9aecc001e0345bcb.jpg",
    },
    {
      cowo: "https://telegra.ph/file/96ec70440ca9d88172098.jpg",
      cewe: "https://telegra.ph/file/de6e98278a4702931aa67.jpg",
    },
    {
      cowo: "https://telegra.ph/file/a38c9142f68601feda2c1.jpg",
      cewe: "https://telegra.ph/file/91227b495ef9c93cfa224.jpg",
    },
    {
      cowo: "https://telegra.ph/file/a53bb937c76450ca2a3e7.jpg",
      cewe: "https://telegra.ph/file/ab3fcfe6e6bf13ff52a40.jpg",
    },
    {
      cowo: "https://telegra.ph/file/8aa6b064c94f78bb02794.jpg",
      cewe: "https://telegra.ph/file/cd83c719baf34c9afdd46.jpg",
    },
    {
      cowo: "https://telegra.ph/file/01038b5362f78dc846851.jpg",
      cewe: "https://telegra.ph/file/148450866b05008846474.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7be6984e0cf4faf7a3893.jpg",
      cewe: "https://telegra.ph/file/4634d87327c4c250b132d.jpg",
    },
    {
      cowo: "https://telegra.ph/file/cf65aedebec2cb008bedc.jpg",
      cewe: "https://telegra.ph/file/2841fa6f6919bdc44e328.jpg",
    },
    {
      cowo: "https://telegra.ph/file/2b21fc3fdee4a699bd96a.jpg",
      cewe: "https://telegra.ph/file/e23b2d98afd0d490ea2ae.jpg",
    },
    {
      cowo: "https://telegra.ph/file/5c40eef57b2f23c63b481.jpg",
      cewe: "https://telegra.ph/file/b1610ccd6cd21efae0303.jpg",
    },
    {
      cowo: "https://telegra.ph/file/5a5aee6ceed6868765b79.jpg",
      cewe: "https://telegra.ph/file/89f91b73fb386fdb42477.jpg",
    },
    {
      cowo: "https://telegra.ph/file/ab178e89550cf64d03942.jpg",
      cewe: "https://telegra.ph/file/d523a8124bd6a87fa3830.jpg",
    },
    {
      cowo: "https://telegra.ph/file/961f9279c5827e9d887bf.jpg",
      cewe: "https://telegra.ph/file/c86bbc615fa38fb3dc30c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/9d47e76049563389416a5.jpg",
      cewe: "https://telegra.ph/file/536184407a378bc69abea.jpg",
    },
    {
      cowo: "https://telegra.ph/file/d2566faf5ad5261695a06.jpg",
      cewe: "https://telegra.ph/file/f14048dc6cf923f7a9528.jpg",
    },
    {
      cowo: "https://telegra.ph/file/67d2b2c059bb8e1e7351b.jpg",
      cewe: "https://telegra.ph/file/8e3e70e67b820f1699608.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c8ec81b71158d178e5065.jpg",
      cewe: "https://telegra.ph/file/d2c5e70ac006bc3cbeb93.jpg",
    },
    {
      cowo: "https://telegra.ph/file/cec46eb42e652f3efb4f1.jpg",
      cewe: "https://telegra.ph/file/99d65a2e1abf5a6ad0d34.jpg",
    },
    {
      cowo: "https://telegra.ph/file/4b053b3be4ccba70b7c72.jpg",
      cewe: "https://telegra.ph/file/dbde211df71815a9f1def.jpg",
    },
    {
      cowo: "https://telegra.ph/file/29e6ddd06724c46ff3097.jpg",
      cewe: "https://telegra.ph/file/e85fd0685bb0ea08dd4cc.jpg",
    },
    {
      cowo: "https://telegra.ph/file/0d7c7da08b6cb198ea6ed.jpg",
      cewe: "https://telegra.ph/file/9b4f661578d6ca609d930.jpg",
    },
    {
      cowo: "https://telegra.ph/file/a16dd1798043047333f0f.jpg",
      cewe: "https://telegra.ph/file/264a88150715e177e9c51.jpg",
    },
    {
      cowo: "https://telegra.ph/file/df380c8a44978047efdf0.jpg",
      cewe: "https://telegra.ph/file/7d4cf40caf59d46632e5a.jpg",
    },
    {
      cowo: "https://telegra.ph/file/92b72edfc1c2bc4cfd74e.jpg",
      cewe: "https://telegra.ph/file/d4e29714041be7360d8fb.jpg",
    },
    {
      cowo: "https://telegra.ph/file/1bfd93d0d238c8b94d527.jpg",
      cewe: "https://telegra.ph/file/95f242ee18810989e14bc.jpg",
    },
    {
      cowo: "https://telegra.ph/file/054f5cbf3290b8784806f.jpg",
      cewe: "https://telegra.ph/file/69609bdc9f31c456c828c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b9b45b469f239e214bfb5.jpg",
      cewe: "https://telegra.ph/file/4f0e077e6424938f1e8d0.jpg",
    },
    {
      cowo: "https://telegra.ph/file/852997b1bbcaf583c4e89.jpg",
      cewe: "https://telegra.ph/file/3c489f0c0868eaae49e70.jpg",
    },
    {
      cowo: "https://telegra.ph/file/94b24f5ae1479064a12ce.jpg",
      cewe: "https://telegra.ph/file/e7fa91928c373a084d2ca.jpg",
    },
    {
      cowo: "https://telegra.ph/file/83506a896dd360f296c9e.jpg",
      cewe: "https://telegra.ph/file/a8840866b9ae9fc295ae6.jpg",
    },
    {
      cowo: "https://telegra.ph/file/9e147224aa6b383283fa7.jpg",
      cewe: "https://telegra.ph/file/e61047e1e06ed2a25522c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/fd50fd0c241781c5ef17b.jpg",
      cewe: "https://telegra.ph/file/23708a54b8c198ca23635.jpg",
    },
    {
      cowo: "https://telegra.ph/file/08211ec0df8b1d4100f95.jpg",
      cewe: "https://telegra.ph/file/feffef2c1c32a2ac3e587.jpg",
    },
    {
      cowo: "https://telegra.ph/file/8da7047b71e2faaaf194b.jpg",
      cewe: "https://telegra.ph/file/ff86c73cabf4b7e3651e3.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c234bb6cefc3196c2900c.jpg",
      cewe: "https://telegra.ph/file/c73f0135e4de5d87807b9.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f055031b37d92f37d4fc6.jpg",
      cewe: "https://telegra.ph/file/f403a8938672ebb35c453.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f3aff2fb22597fe22dfee.jpg",
      cewe: "https://telegra.ph/file/26a8d7f81e261260ef7be.jpg",
    },
    {
      cowo: "https://telegra.ph/file/9b1f9063c0d16c447ccdf.jpg",
      cewe: "https://telegra.ph/file/07014bb11526fc4603bbc.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7bd03478c96733864585e.jpg",
      cewe: "https://telegra.ph/file/62416a0f8e6758f6ca423.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c0713048885d741d6f8f9.jpg",
      cewe: "https://telegra.ph/file/b993c8e9b2c70d46cf4b3.jpg",
    },
    {
      cowo: "https://telegra.ph/file/d50735c11cf8528dd89a4.jpg",
      cewe: "https://telegra.ph/file/b7eced89528d2278f18db.jpg",
    },
    {
      cowo: "https://telegra.ph/file/bf6c9a243f9191db5cffd.jpg",
      cewe: "https://telegra.ph/file/7ff0b5bf1bfe36e7df58f.jpg",
    },
    {
      cowo: "https://telegra.ph/file/469c1f2437a367a021f94.jpg",
      cewe: "https://telegra.ph/file/eccc339d655436bd018b0.jpg",
    },
    {
      cowo: "https://telegra.ph/file/8e122a3326f60e58d0efd.jpg",
      cewe: "https://telegra.ph/file/b2c13cad7ba11f8d6d525.jpg",
    },
    {
      cowo: "https://telegra.ph/file/64aab239b1835fbf3ea2c.jpg",
      cewe: "https://telegra.ph/file/9513de7dd4e09f1f1c560.jpg",
    },
    {
      cowo: "https://telegra.ph/file/064a1c7409f0563dfa14b.jpg",
      cewe: "https://telegra.ph/file/0b9f75a3c8718cfef6bbf.jpg",
    },
    {
      cowo: "https://telegra.ph/file/d32be33cbcd1defd90fa3.jpg",
      cewe: "https://telegra.ph/file/067ea50f32073c5497069.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f334cbc4eafe58eba5156.jpg",
      cewe: "https://telegra.ph/file/559646ec50f84afb2f20a.jpg",
    },
    {
      cowo: "https://telegra.ph/file/61471e2c9ac42334bb7ea.jpg",
      cewe: "https://telegra.ph/file/9d7e2d39ac88a585b5287.jpg",
    },
    {
      cowo: "https://telegra.ph/file/04c4578431ae13989737a.jpg",
      cewe: "https://telegra.ph/file/27e9a1df4870bbdd2a8e9.jpg",
    },
    {
      cowo: "https://telegra.ph/file/5e8ed50e1f99e007642f7.jpg",
      cewe: "https://telegra.ph/file/593a0b16c2127f664a18f.jpg",
    },
    {
      cowo: "https://telegra.ph/file/a2d93857b7b424d97ac91.jpg",
      cewe: "https://telegra.ph/file/1f6c009ffe9e1f6a02255.jpg",
    },
    {
      cowo: "https://telegra.ph/file/82435a21b758159bb828b.jpg",
      cewe: "https://telegra.ph/file/30ddfb1131a9eec9e385e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/6e9e9b953fd2160760b49.jpg",
      cewe: "https://telegra.ph/file/798356928cb0740d81cae.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f2b91026b2598937ef4d8.jpg",
      cewe: "https://telegra.ph/file/f2161c5e4b2e184534ae2.jpg",
    },
    {
      cowo: "https://telegra.ph/file/72568767bab13649752c3.jpg",
      cewe: "https://telegra.ph/file/6db5bf215d3452e76424b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/9ca20cc513ff24ec873d2.jpg",
      cewe: "https://telegra.ph/file/d59ddd53ecd16de6af06f.jpg",
    },
    {
      cowo: "https://telegra.ph/file/619407af0cbd93bf134ad.jpg",
      cewe: "https://telegra.ph/file/7020115f0b09cc5481bb7.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7fadc734c8d8d48e54951.jpg",
      cewe: "https://telegra.ph/file/d1cc8fcd04bf67a956090.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7aac083ab451f091e4426.jpg",
      cewe: "https://telegra.ph/file/74a3c371af5141387c79e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7ad33fa600b9843879387.jpg",
      cewe: "https://telegra.ph/file/427e88274fd882939368b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/35d8df57ba37cb384ba88.jpg",
      cewe: "https://telegra.ph/file/941f863e6ce14ff36571a.jpg",
    },
    {
      cowo: "https://telegra.ph/file/edbd4e132a925cc5a8c8e.jpg",
      cewe: "https://telegra.ph/file/91f9bafbe6315cf559655.jpg",
    },
    {
      cowo: "https://telegra.ph/file/ca48b265ff80a084477d7.jpg",
      cewe: "https://telegra.ph/file/12c97cc0b39f9066f6a03.jpg",
    },
    {
      cowo: "https://telegra.ph/file/0a991d63075d6c9a65970.jpg",
      cewe: "https://telegra.ph/file/fb7dfbde386bd560e3cf4.jpg",
    },
    {
      cowo: "https://telegra.ph/file/af13da298e039f9f20a10.jpg",
      cewe: "https://telegra.ph/file/b09c9c57bc2140054ce8c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/1b4178bd47b260c03cf18.jpg",
      cewe: "https://telegra.ph/file/8f3c84270baac642d9ee6.jpg",
    },
    {
      cowo: "https://telegra.ph/file/275f18751231ff219be2d.jpg",
      cewe: "https://telegra.ph/file/46cc93067a2f49958d49f.jpg",
    },
    {
      cowo: "https://telegra.ph/file/26943402bc928ac8f9d36.jpg",
      cewe: "https://telegra.ph/file/93a2223144cd55536ebb0.jpg",
    },
    {
      cowo: "https://telegra.ph/file/d69d2f1e333a03b306e69.jpg",
      cewe: "https://telegra.ph/file/7ec05ebe1a51a23e65e3e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/3a6345efb7bb6a80f8555.jpg",
      cewe: "https://telegra.ph/file/ee0d951ed163aa986d81e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/2da77e5304c3ba2ebfeb8.jpg",
      cewe: "https://telegra.ph/file/6d8d9b37b47676676ab96.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b8fef38c44d28761e10d4.jpg",
      cewe: "https://telegra.ph/file/7e619e6f2a5353abfed30.jpg",
    },
    {
      cowo: "https://telegra.ph/file/839ae86dbbfd6433dea83.jpg",
      cewe: "https://telegra.ph/file/9dac4f06f2235bdf40504.jpg",
    },
    {
      cowo: "https://telegra.ph/file/96d4ba116f37800496924.jpg",
      cewe: "https://telegra.ph/file/ac3f48e9d86bb58990cc6.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7b3ea8170828585e62b26.jpg",
      cewe: "https://telegra.ph/file/ac743999d3ca2b1393a54.jpg",
    },
    {
      cowo: "https://telegra.ph/file/416a00d277967ae621a67.jpg",
      cewe: "https://telegra.ph/file/72b1e718529eb439687e3.jpg",
    },
    {
      cowo: "https://telegra.ph/file/0d621a61c352652fb88d4.jpg",
      cewe: "https://telegra.ph/file/c1b110c3aed49d57c2347.jpg",
    },
    {
      cowo: "https://telegra.ph/file/a5265c2329250c6ac7468.jpg",
      cewe: "https://telegra.ph/file/e2165f02041df1b1929c5.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f831c1a95e73ebe09f91b.jpg",
      cewe: "https://telegra.ph/file/51c31283364ecd039d58e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/eff24fd96ab4f56b486da.jpg",
      cewe: "https://telegra.ph/file/5ab9a14e90d4cd5f1f000.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c8fb66898a59572abce23.jpg",
      cewe: "https://telegra.ph/file/02a8244c9d7676191e943.jpg",
    },
    {
      cowo: "https://telegra.ph/file/08a83f29986cab8116477.jpg",
      cewe: "https://telegra.ph/file/117def22fabc7c4b75d58.jpg",
    },
    {
      cowo: "https://telegra.ph/file/eb099a00f69e0f4fabbd0.jpg",
      cewe: "https://telegra.ph/file/e88ef8525eb2a3932a7bb.jpg",
    },
    {
      cowo: "https://telegra.ph/file/061f803da526b09ab1c3e.jpg",
      cewe: "https://telegra.ph/file/92d09c11c557ab5e99bd3.jpg",
    },
    {
      cowo: "https://telegra.ph/file/fe0faf9ec72674ccd9bb9.jpg",
      cewe: "https://telegra.ph/file/7e5d1e0cdf3518e0d5742.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b8cd4b34f5a94dbc1b176.jpg",
      cewe: "https://telegra.ph/file/a046bb397d33d211bea28.jpg",
    },
    {
      cowo: "https://telegra.ph/file/3880a510282e059e5419f.jpg",
      cewe: "https://telegra.ph/file/4f21aaf8d4bbfa9ab6ac7.jpg",
    },
    {
      cowo: "https://telegra.ph/file/4fa4d5724cdfffcbb4598.jpg",
      cewe: "https://telegra.ph/file/f06497f9d98db132ec0b1.jpg",
    },
    {
      cowo: "https://telegra.ph/file/5ccd5b511b46d7845519b.jpg",
      cewe: "https://telegra.ph/file/3d62d5d45a1609491a2ab.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7dadb7ecc5698d94a753c.jpg",
      cewe: "https://telegra.ph/file/a1dd88b9f834ae7598b36.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f7fd78e78c48a8580d5db.jpg",
      cewe: "https://telegra.ph/file/c0fd6b122bd3df0683c7e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/72e295b2420b9b9c15058.jpg",
      cewe: "https://telegra.ph/file/056d033421419527fd490.jpg",
    },
    {
      cowo: "https://telegra.ph/file/96f2a8acb4e7a7cedd103.jpg",
      cewe: "https://telegra.ph/file/027335706455ce6db6c57.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7248809232f273c95e3d9.jpg",
      cewe: "https://telegra.ph/file/a9588e8740901694b4dff.jpg",
    },
    {
      cowo: "https://telegra.ph/file/fa22d68b52811e70ab23a.jpg",
      cewe: "https://telegra.ph/file/bba565543e329963b93f9.jpg",
    },
    {
      cowo: "https://telegra.ph/file/945f1273c058d0340b0c9.jpg",
      cewe: "https://telegra.ph/file/dff38097ff386d4a7aa7b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/022b841bd298232f4b834.jpg",
      cewe: "https://telegra.ph/file/5d3e77b951edda2a70c4c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7f5ceba1d60759eaafe38.jpg",
      cewe: "https://telegra.ph/file/d5334fb90b5390b804810.jpg",
    },
    {
      cowo: "https://telegra.ph/file/e3bd655fe83977f9146d5.jpg",
      cewe: "https://telegra.ph/file/2c6f7b966c3b7578c4d6f.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7e7a60afd247acc6a6a38.jpg",
      cewe: "https://telegra.ph/file/e8de9861726dfebc968de.jpg",
    },
    {
      cowo: "https://telegra.ph/file/296c3e2f21e253e3ce661.jpg",
      cewe: "https://telegra.ph/file/44141b4465aed5310e5e4.jpg",
    },
    {
      cowo: "https://telegra.ph/file/e8d2c356d6c6d20c9c860.jpg",
      cewe: "https://telegra.ph/file/b96aec21c31a2d52fa43b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b8b90142e9b045938e2fd.jpg",
      cewe: "https://telegra.ph/file/675dd63e56f76e68f85dc.jpg",
    },
    {
      cowo: "https://telegra.ph/file/d5f973a637ce27554a2ae.jpg",
      cewe: "https://telegra.ph/file/3c209d9160e112b2e8780.jpg",
    },
    {
      cowo: "https://telegra.ph/file/baf3e68be7cd1b206c20d.jpg",
      cewe: "https://telegra.ph/file/196777fe4ac5c426f90a2.jpg",
    },
    {
      cowo: "https://telegra.ph/file/2538a9d5d86fcc480cc42.jpg",
      cewe: "https://telegra.ph/file/e34d5d3c6d89c0b97df09.jpg",
    },
    {
      cowo: "https://telegra.ph/file/add9b563d8b86cb9a0e01.jpg",
      cewe: "https://telegra.ph/file/e010c4bb7dde6424d83bd.jpg",
    },
    {
      cowo: "https://telegra.ph/file/20d52361f4cc4ae609b47.jpg",
      cewe: "https://telegra.ph/file/abc7b9c8bab19c9f6c3e5.jpg",
    },
    {
      cowo: "https://telegra.ph/file/d81d8a5cd604ac413a20a.jpg",
      cewe: "https://telegra.ph/file/6787c8bb17ce207d835d9.jpg",
    },
    {
      cowo: "https://telegra.ph/file/59cb00804f8b390869092.jpg",
      cewe: "https://telegra.ph/file/85c310560d01841baf7e6.jpg",
    },
    {
      cowo: "https://telegra.ph/file/4432330ac1ff9d3de83b2.jpg",
      cewe: "https://telegra.ph/file/0112ccb9d98eac181cb38.jpg",
    },
    {
      cowo: "https://telegra.ph/file/60faab940a8a9b0645aa6.jpg",
      cewe: "https://telegra.ph/file/3723b8c2fc9e8ba96634a.jpg",
    },
    {
      cowo: "https://telegra.ph/file/eae89cc3547b5212961cc.jpg",
      cewe: "https://telegra.ph/file/fa3d7d38bb3be824f1779.jpg",
    },
    {
      cowo: "https://telegra.ph/file/33728392349adb62c342b.jpg",
      cewe: "https://telegra.ph/file/7cf1b5f9b1c57af26f44a.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b2e69cf82653fac4ceeeb.jpg",
      cewe: "https://telegra.ph/file/1123fe6c0f1d8080b22ce.jpg",
    },
    {
      cowo: "https://telegra.ph/file/845e80d0af817840a8ed0.jpg",
      cewe: "https://telegra.ph/file/117b848dbd37f9d60642c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/111f68ff6aecde6ad4dd2.jpg",
      cewe: "https://telegra.ph/file/760b257e4f25d70a124cc.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b17bfd65559c381246dbb.jpg",
      cewe: "https://telegra.ph/file/c4f8a8ae88e4b1c183aec.jpg",
    },
    {
      cowo: "https://telegra.ph/file/e36b61278c0f84c9050ea.jpg",
      cewe: "https://telegra.ph/file/da252881f6dcacf39d919.jpg",
    },
    {
      cowo: "https://telegra.ph/file/cc21048c0fe572acd6c68.jpg",
      cewe: "https://telegra.ph/file/70482849c195759af6408.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c46bc8e406061f958b7de.jpg",
      cewe: "https://telegra.ph/file/da44554746a1f4546583e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/cde70ac70a1e518b70e36.jpg",
      cewe: "https://telegra.ph/file/b8c5c398d5c1cd2fe377c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/e8830b9bf9baa7df831ac.jpg",
      cewe: "https://telegra.ph/file/6f427010ac21705e62b9e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/381f804edc991afe8d2d3.jpg",
      cewe: "https://telegra.ph/file/2ba06789d5b2bff96df14.jpg",
    },
    {
      cowo: "https://telegra.ph/file/e775c924c46a671e65b7b.jpg",
      cewe: "https://telegra.ph/file/ea67ffd0a5cb7657da974.jpg",
    },
    {
      cowo: "https://telegra.ph/file/1063d21bc0079f0032f54.jpg",
      cewe: "https://telegra.ph/file/a260ee2a73ba6ecad7f1a.jpg",
    },
    {
      cowo: "https://telegra.ph/file/40fdf138e558ba1075378.jpg",
      cewe: "https://telegra.ph/file/69920b3423aa8a0e63faf.jpg",
    },
    {
      cowo: "https://telegra.ph/file/1ead49a57800109e875b4.jpg",
      cewe: "https://telegra.ph/file/0a59faa16e7c65a658e23.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7917fa875457b55fabc24.jpg",
      cewe: "https://telegra.ph/file/445e42ab978ad74530b61.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f1b3f7dec4c5ee1cc8829.jpg",
      cewe: "https://telegra.ph/file/4433b7b8c2720ca40853c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/bb8936522e6d30181a9fe.jpg",
      cewe: "https://telegra.ph/file/b45ccf0c809173796a69e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f28e2870e06c305f8007a.jpg",
      cewe: "https://telegra.ph/file/6d10d8f9edd867e1a253d.jpg",
    },
    {
      cowo: "https://telegra.ph/file/051abd1f27546633100fe.jpg",
      cewe: "https://telegra.ph/file/12ccecfa40ec216e699a2.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c08041f91d0f190be1892.jpg",
      cewe: "https://telegra.ph/file/ede66318220c39e8893e1.jpg",
    },
    {
      cowo: "https://telegra.ph/file/0123d2aa4561632c89db8.jpg",
      cewe: "https://telegra.ph/file/567f1e05fcd9dd38b56e8.jpg",
    },
    {
      cowo: "https://telegra.ph/file/514ce6f8515d2fad09398.jpg",
      cewe: "https://telegra.ph/file/ca0a6f4d7efab8b44cbff.jpg",
    },
    {
      cowo: "https://telegra.ph/file/674e5874930cecb9e23d7.jpg",
      cewe: "https://telegra.ph/file/ad17dac5e5163f4dce5b0.jpg",
    },
    {
      cowo: "https://telegra.ph/file/91ec11d90e027284d39d1.jpg",
      cewe: "https://telegra.ph/file/2658bcb3a4909fd2df62b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/91795483d752ed1223578.jpg",
      cewe: "https://telegra.ph/file/85964e619a7e13469332e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/43c8e0a0417243575921e.jpg",
      cewe: "https://telegra.ph/file/17d888a9f79ab8c7e773a.jpg",
    },
    {
      cowo: "https://telegra.ph/file/2dec802e6e5f39cfee297.jpg",
      cewe: "https://telegra.ph/file/15e326ac0e810239b6c5e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c990af11010c57b10c04d.jpg",
      cewe: "https://telegra.ph/file/27bf584ae5acbe9ce615d.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f0d3d224834238a49003f.jpg",
      cewe: "https://telegra.ph/file/dde062a11239ac0aa571f.jpg",
    },
    {
      cowo: "https://telegra.ph/file/cf7b26f5430646c74fc28.jpg",
      cewe: "https://telegra.ph/file/602efb4d2fb943894c0e5.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b2924fe3f44b94d995ff7.jpg",
      cewe: "https://telegra.ph/file/cc60d2d762701f3f61b45.jpg",
    },
    {
      cowo: "https://telegra.ph/file/03fbf15f1bc39abc84e01.jpg",
      cewe: "https://telegra.ph/file/bb26db4d79ea9061142a7.jpg",
    },
    {
      cowo: "https://telegra.ph/file/ec65bcb7af02eb8ff3bdd.jpg",
      cewe: "https://telegra.ph/file/82337c7d1cb58fd4f71fe.jpg",
    },
    {
      cowo: "https://telegra.ph/file/15df55c4de32a5d1e6eb1.jpg",
      cewe: "https://telegra.ph/file/3fa9693a4f50c0fb529c0.jpg",
    },
    {
      cowo: "https://telegra.ph/file/e959ca134be65f10f0530.jpg",
      cewe: "https://telegra.ph/file/1d5dfa5710970038b00be.jpg",
    },
    {
      cowo: "https://telegra.ph/file/866b9a4d7762dd7bc66ed.jpg",
      cewe: "https://telegra.ph/file/5afbe39b92b6934aee0ca.jpg",
    },
    {
      cowo: "https://telegra.ph/file/6b79b1fd84306e05aea63.jpg",
      cewe: "https://telegra.ph/file/4491c801ca088e41ca6eb.jpg",
    },
    {
      cowo: "https://telegra.ph/file/1cec775c7b9c4dee040d7.jpg",
      cewe: "https://telegra.ph/file/ff70952e7a850d8077d13.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f99f8eef6836d00bb995a.jpg",
      cewe: "https://telegra.ph/file/767976d9fae1318c395aa.jpg",
    },
    {
      cowo: "https://telegra.ph/file/80e67ded339159a80155c.jpg",
      cewe: "https://telegra.ph/file/1498311e2a640af606ec1.jpg",
    },
    {
      cowo: "https://telegra.ph/file/b0c0e15269e44e160763c.jpg",
      cewe: "https://telegra.ph/file/39e15219e56bade7a64d0.jpg",
    },
    {
      cowo: "https://telegra.ph/file/68aba5456132af0acf10d.jpg",
      cewe: "https://telegra.ph/file/448aa3f23c88ce88cfbc2.jpg",
    },
    {
      cowo: "https://telegra.ph/file/e9ac56a06df68b87718f4.jpg",
      cewe: "https://telegra.ph/file/b6d1a3398bbf148db4b7e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/26528b7a1f946dda51273.jpg",
      cewe: "https://telegra.ph/file/b560c2121ec774d6c5f68.jpg",
    },
    {
      cowo: "https://telegra.ph/file/c08f8a0ceb9a9949e8830.jpg",
      cewe: "https://telegra.ph/file/c85f743332b2026ec796b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/177703b3667936b3c83dd.jpg",
      cewe: "https://telegra.ph/file/24c6f4386ffdb4af0cfd9.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7b8ecf13406a68bfdaf24.jpg",
      cewe: "https://telegra.ph/file/7aab70000cf0e11f9611b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/77d13e94198c37654ef6d.jpg",
      cewe: "https://telegra.ph/file/f38449a23ec6dc378dd58.jpg",
    },
    {
      cowo: "https://telegra.ph/file/6af4ca5953f6c500acf55.jpg",
      cewe: "https://telegra.ph/file/c1400ecce5cd67db68f68.jpg",
    },
    {
      cowo: "https://telegra.ph/file/3854aa77759e19daa0660.jpg",
      cewe: "https://telegra.ph/file/092ab5b9f8c9352c8159c.jpg",
    },
    {
      cowo: "https://telegra.ph/file/868f7644cf5f9dc31075a.jpg",
      cewe: "https://telegra.ph/file/1fe02fad98d3888fac044.jpg",
    },
    {
      cowo: "https://telegra.ph/file/3cc242bd90908f1d4b71c.jpg",
      cewe: "https://telegra.ph/file/1a58282099d29640ead7e.jpg",
    },
    {
      cowo: "https://telegra.ph/file/dc6e829cff0b29dd2f2d6.jpg",
      cewe: "https://telegra.ph/file/025ff61bc55c70c3b6d7b.jpg",
    },
    {
      cowo: "https://telegra.ph/file/7324278a32dfcf075fc9c.jpg",
      cewe: "https://telegra.ph/file/8e28f86ff322e0bf60673.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f76c87e8ded74a146ec67.jpg",
      cewe: "https://telegra.ph/file/2d1f5a7d42f699fc09f52.jpg",
    },
    {
      cowo: "https://telegra.ph/file/d2a7c636ac1cf377d0d03.jpg",
      cewe: "https://telegra.ph/file/53bb9df2c040fe509b1b5.jpg",
    },
    {
      cowo: "https://telegra.ph/file/f1a30729a77af20fbe6b9.jpg",
      cewe: "https://telegra.ph/file/93a8676efc0c632ab0c94.jpg",
    },
  ];
}
async function lolivid() {
  return await (
    await axios.get("https://api.cafirexos.com/api/anime/lolivid")
  ).data;
}
module.exports = {
  randomCerpen,
  ceritahntu,
  ppcouple,
  lolivid,
};
